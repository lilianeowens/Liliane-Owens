import java.util.Objects;
import java.util.Scanner;

public class MemoryCalc {

	private double currentValue;	
	
	public double getCurrentValue() {
		return currentValue;
	}

	public void setCurrentValue(double currentValue) {
		this.currentValue = currentValue;
	}

	public int displayMenu() {
		Scanner input = new Scanner(System.in);

		int menu = -1;

		while (menu < 1 || menu > 6) {
			System.out.println();
			System.out.println("Menu");
			System.out.println("1. Add");
			System.out.println("2. Subtract");
			System.out.println("3. Multiply");
			System.out.println("4. Divide");
			System.out.println("5. Clear");
			System.out.println("6. Quit");
			System.out.println();
			System.out.print("What would you like to do? ");

			menu = input.nextInt();

			if (menu < 1 || menu > 6) {
				System.out.println(menu + " wasn't one of the options");
			}

			if (menu == 6) {
				System.out.println("Goodbye!");
				System.exit(0);
			}
		}

		return menu;
	}

	public double getOperand(String prompt) {
		Scanner input = new Scanner(System.in);
		System.out.print(prompt);
		return input.nextDouble();
	}

	public void add(double operand2) {
		currentValue += operand2;
	}
	
	public void subtract(double operand2) {
		currentValue -= operand2;
	}
	
	public void multiply(double operand2) {
		currentValue *= operand2;
	}
	
	public void divide(double operand2) {
		if (operand2 == 0) {
			currentValue /= Double.NaN;
		}
		else
			currentValue /= operand2;
	}

	public void clear() {
		currentValue = 0;
	}

	
	@Override
	public int hashCode() {
		return Objects.hash(currentValue);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MemoryCalc other = (MemoryCalc) obj;
		return Double.doubleToLongBits(currentValue) == Double.doubleToLongBits(other.currentValue);
	}

	@Override
	public String toString() {
		return "MemoryCalc [currentValue=" + currentValue + "]";
	}
}




