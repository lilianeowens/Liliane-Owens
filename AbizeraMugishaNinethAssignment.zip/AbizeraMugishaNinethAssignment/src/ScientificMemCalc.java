import java.util.Scanner;

public class ScientificMemCalc extends MemoryCalc{

	//Constructor
	public ScientificMemCalc() {

	}

	//method for raising the power of current value to an operand2 the user entered
	public void power(double operand2) {
		setCurrentValue(Math.pow(getCurrentValue(), operand2));
	}

	// method for natural logarithm
	public void logarithm() {
		setCurrentValue(Math.log(getCurrentValue()));
	}
//Override display menu from MemoryCalc

	public int displayMenu() {
		Scanner input = new Scanner(System.in);

		int menu = -1;

		while (menu < 1 || menu > 8) {
			System.out.println();
			System.out.println("Menu");
			System.out.println("1. Add");
			System.out.println("2. Subtract");
			System.out.println("3. Multiply");
			System.out.println("4. Divide");
			System.out.println("5. Power");
			System.out.println("6. Logarithm");
			System.out.println("7. Clear");
			System.out.println("8. Quit");
			System.out.println();
			System.out.print("What would you like to do? ");

			menu = input.nextInt();

			if (menu < 1 || menu > 8) {
				System.out.println(menu + " wasn't one of the options");
			}

			if (menu == 8) {
				System.out.println("Goodbye!");
				System.exit(0);
			}
		}

		return menu;
	}

	public String toString() {
		return "ScientificMemCalc [displayMenu()=" + displayMenu() + ", getCurrentValue()=" + getCurrentValue()
		+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + ", getClass()=" + getClass()
		+ "]";
	}
}
