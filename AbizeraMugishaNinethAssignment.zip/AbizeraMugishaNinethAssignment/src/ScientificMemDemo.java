import java.util.Scanner;

public class ScientificMemDemo {

	public static void main(String[] args) {

		Scanner inKeyboard = new Scanner(System.in);	
		String message = "what is the second number ?";
		double op2;

		ScientificMemCalc calc = new ScientificMemCalc();

		System.out.println("The current value is  " + calc.getCurrentValue() );
		int choice;
		
		do {
			choice = calc.displayMenu(); // Invoke the display menu from ScientificMemCalc class

			switch (choice) { 

			case 1:// Add

				op2 = calc.getOperand(message);

				calc.add(op2);
				System.out.println("The current value is " + calc.getCurrentValue());
				break;

			case 2: // Subtract 

				op2 = calc.getOperand(message);

				calc.subtract(op2);

				System.out.println("The current value is " + calc.getCurrentValue());

				break;

			case 3:// Multiply 
				op2 = calc.getOperand(message);

				calc.multiply(op2);

				System.out.println("The current value is " + calc.getCurrentValue());
				break;

			case 4: // Divide 
				op2 = calc.getOperand(message);

				calc.divide(op2);

				System.out.println("The current value is " + calc.getCurrentValue());

				break;

			case 5: // Power

				op2 = calc.getOperand(message);

				calc.power(op2);

				System.out.println("The current value is " + calc.getCurrentValue());

				break;

			case 6: //Logarithm

				calc.logarithm();

				System.out.println("The current value is " + calc.getCurrentValue()); 

				break;


			case 7: // Clear

				calc.clear();

				System.out.println("The current value is " + calc.getCurrentValue());

				break;

			case 8:// Quit 
				System.out.println("Goodbye!"); 
				break;

			default:
				System.out.println("I am sorry, " + choice + " was not one of the options.\n");
			}

		}while(choice != 8);

		inKeyboard.close();
	}



}


