/*Mugisha Liliane Abizera
 CIS 1111
 2D Arrays Assignment
 8/1/2021*/

#include<iostream>
#include<fstream>
#include<string>
#include<iomanip>

using namespace std;

void displayChart(string months[], int visitors[][9])
{
	// display the chart
	cout << "Visitors to the park by month and Type:" << endl << endl;
	cout << "Month        T Rec     T Non-Rec  Con Lodging    Tent        RV     Con Camp  Back Country Misc camp T Overnite " << endl;
	for(int r = 0; r < 12; r++)
	{
		cout << setw(11) << left << months[r];
		for(int c = 0; c < 9; c++)
		{
			cout << setw(8) << right << visitors[r][c] << "   ";
		}
		    cout << endl;
	}
}

void getTotalRecNonRec(string months[], int visitors[][9])
{
	int totalRecNRec = 0;
	for (int i = 0; i < 12; i++)
	{

       totalRecNRec += visitors[i][0]+visitors[i][1];
			
	}
	cout << "The total number of recreation and non-recreational visitors:  " << totalRecNRec << endl <<endl;
		
}

void getTotalTentRv(string months[], int visitors[][9])
{
	cout << "Total tent and Rv campers by month: " << endl;
	
	for (int i = 0; i < 12; i++) {

		cout << setw(11) << left << months[i];
		
		cout << setw(8) << right << visitors[i][3] + visitors[i][4]<<endl;
		}
	
}

void displayRecVisitors(string months[], int visitors[][9]) {
	string Monthname;

	cout << "Enter the month you want the number of recreational visitors " << endl;
	cin >> Monthname;
	if (Monthname == "January") 
	{
		cout << "For the month " << Monthname << " there were " << visitors[0][0] << " recreational visitors " <<endl;
	}
	else if (Monthname == "February")
	{
		cout << "For the month " << Monthname << " there were " << visitors[1][0] << " recreational visitors " <<endl;
	}
	else if (Monthname == "March")
	{
		cout << "For the month " << Monthname << " there were " << visitors[2][0] << " recreational visitors " <<endl;
	}
	else if (Monthname == "April")
	{
		cout << "For the month " << Monthname << " there were " << visitors[3][0] << " recreational visitors " <<endl;
	}
	else if (Monthname == "May")
	{
		cout << "For the month " << Monthname << " there were " << visitors[4][0] << " recreational visitors " <<endl;
	}
	else if (Monthname == "June")
	{
		cout << "For the month " << Monthname << " there were " << visitors[5][0] << " recreational visitors " <<endl;
	}
	else if (Monthname == "July")
	{
		cout << "For the month " << Monthname << " there were " << visitors[6][0] << " recreational visitors " <<endl;
	}
	else if (Monthname == "August")
	{
		cout << "For the month " << Monthname << " there were " << visitors[7][0] << " recreational visitors " <<endl;
	}
	else if (Monthname == "September")
	{
		cout << "For the month " << Monthname << " there were " << visitors[8][0] << " recreational visitors " <<endl;
	}
	else if (Monthname == "October")
	{
		cout << "For the month " << Monthname << " there were " << visitors[9][0] << " recreational visitors " <<endl;
	}
	else if (Monthname == "November")
	{
		cout << "For the month " << Monthname << " there were " << visitors[10][0] << " recreational visitors " <<endl;
	}
	else if (Monthname == "December")
	{
		cout << "For the month " << Monthname << " there were " << visitors[11][0] << " recreational visitors " <<endl;
	}
	else
		cout << " This month does not exist " << endl;
	
}


int main()
{
	string months[12];
	int visitors[12][9];
	int choice;
	int totalRecNRec{};

	const int chart_choice = 1,
		TotRecNRec_choice = 2,
		TotalTentRv_choice = 3,
		RecVis_choice = 4;
		  

	ifstream monthsFile;
	monthsFile.open("months.txt");
	for (int i = 0; i < 12; i++)
	{
		monthsFile >> months[i];
	}
	monthsFile.close();

	// read in visitors
	ifstream visitorsFile;
	visitorsFile.open("AcadiaVisitors.txt");
	for (int r = 0; r < 12; r++)
	{
		for (int c = 0; c < 9; c++)
		{
			visitorsFile >> visitors[r][c];
		}

	}
	visitorsFile.close();
	
	do
	{
		//display the menu
		cout << "Visitors to Acadia National Park " << endl;
		cout << "Type 1 to display the chart:  " << endl;
		cout << "Type 2 to display the total number of recreation and non-recreational:  " << endl;
		cout << "Type 3 to display total number of tent and Rv campers by month " << endl;
		cout << "Type 4 to display the number of recreation visitors for a certain month." << endl;
		cout << "Enter any other months to exit " << endl << endl;
		cout << "enter your selection ";
		cin >> choice;

		// get the menu choice
		switch (choice)
		{
		case 1: // display chart
			displayChart(months, visitors);
			break;
		case 2: // rec/non-rec
		getTotalRecNonRec(months, visitors);
			break;
		case 3: //Total Tent/RV
			getTotalTentRv(months, visitors);
			break;
		case 4: //number of recreational for a certain month
			displayRecVisitors(months, visitors);
			break; 
		}
	} while (choice >= 1 && choice <= 4);

	return 0;
}

