//Liliane
// May 23, 2021
// Week 1 
// Hello World
//My first program that will output Hello World


#include <iostream>

int main()
{
    std::cout << "Hello World!\n";
    system("pause");
    return 0;
}



