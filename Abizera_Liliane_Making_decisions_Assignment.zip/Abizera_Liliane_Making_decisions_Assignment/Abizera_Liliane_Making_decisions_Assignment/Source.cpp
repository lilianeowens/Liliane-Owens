// Mugisha Liliane Abizera
// 6/20/2021
// CIS 1111
// Making Decisions

#include<iostream>
#include<string>
#include<iomanip>
#include<cmath>
using namespace std;

int main()
{
	int nuGuests;
	float lengthMin;
	string nameOfEvent, customerFName;

	cout << "Enter the name of the event: " << endl;
	getline(cin, nameOfEvent);
	cout << "Enter the customer requesting to book:" << endl;
	getline(cin, customerFName);
	cout << "Enter the number of guests to serve: ";
	cin >> nuGuests;
	if (nuGuests >100)
	{
		cout << "you are over the capacity of our club" << endl;
		cout << "try to reduce the number to 100 or go somewhere else";
		cout << "the number of dinners is more than the number of guests" << endl;
		return (0);
	}

	cout << "what is the lenght of the event in minutes ?: ";
	cin >> lengthMin;
	if (lengthMin > 270)
	{
		cout << "your event length is over the time allowed in our club" << endl;
		cout << "try to reduce the time to less than 6 hours otherwise you find somewhere else" << endl;
		return (0);
	}

	int nuChicken, nuSalmon, nuVegetarian, nu_dinners;

	cout << "Enter the number of chicken dinners:    "; cin >> nuChicken;
	cout << "Enter the number of salmon dinners:     "; cin >> nuSalmon;
	cout << "Enter the number of vegetarian dinners: "; cin >> nuVegetarian;
	nu_dinners = nuChicken + nuSalmon + nuVegetarian;
	if (nu_dinners > 100)
	{
		cout << "the number of dinners is more than the number of guests" << endl;
		return (0);
	}
	
	cout << nameOfEvent << endl;
	cout << "Event estimate for  " << customerFName << endl;

	
	int nuServers = nuGuests /20;
	if (nuGuests % 20 == 0)
	{
		cout << "number of server is :" << nuServers << endl << endl;
	}
	else
	{
		 nuServers += 1;
	}
    int duration = 270;
	int hours; 
	int minutes;
	hours = 270 / 60;
	minutes = 270 % 60;
	 
	if (minutes > 0)
		hours += 1;
	double totalCostServers = nuServers * (hours *18.50);
	float Chicken_dinner_cost= 24.50 * nuChicken;
	float salmon_dinner_cost = 32.50 * nuSalmon;
	float vegetarian_dinner_cost = 19.50 * nuVegetarian;
	float totalCostDinner = Chicken_dinner_cost + salmon_dinner_cost + vegetarian_dinner_cost;
	float totalCost = totalCostServers + totalCostDinner;
	double avg_person = totalCost / nuGuests;
	float deposit = totalCost * 0.25;

	cout << setprecision(2) << fixed;
	cout << "How many servers are serving ?           " << setw(7) << nuServers << endl;
	cout << "How much the servers will get paid?      " << setw(10) << totalCostServers << endl;
	cout << "what is the total cost of food:          " << setw(10) << totalCostDinner << endl;
	cout << "what is the average cost per person:     " << setw(10) << avg_person << endl;
	cout << "what is the total cost :                 " << setw(10) << totalCost << endl << endl;
	cout << "Please provide a 25% deposit to reserve the event" << endl;
	cout << "The deposit is :                        " << setw(11) << deposit << endl << endl << endl;
	
	system("pause");
	return(0);
}