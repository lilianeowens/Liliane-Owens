package facebookclasspac;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;
/**
 * 
 * @author R-LO
 *
 */
public class FacebookDriver {
	/**
	 * Fields
	 */
	private static ArrayList<FacebookClass> users;
	private static final String FILENAME = "facebook.dat";
	private static final Scanner IN = new Scanner(System.in);
	private static final PrintStream OUT = System.out;
	private static final PrintStream ERR = System.err;

	/**
	 * The ObjectInputStream class contains readObject() method for deserializing an object.
	 * @throws IOException
	 * @throws ClassNotFoundException
	 */
	public static void readUsers() throws IOException, ClassNotFoundException {
		File inputFile = new File(FILENAME);

		if (!inputFile.exists()) {
			return;
		}

		ObjectInputStream reader = new ObjectInputStream(new FileInputStream(FILENAME));

		users = new ArrayList<FacebookClass>();

		try {
			while (true) // not infinite loop
			{
				FacebookClass nextUser = (FacebookClass) reader.readObject();
				users.add(nextUser);
			}
		} catch (EOFException ex) {
			OUT.println(ex.getMessage());

		}

		reader.close();
	}// end reader users

	/**
	 * The ObjectOutputStream class contains writeObject() method for serializing an Object
	 * @throws IOException
	 */
	public static void writeUsers() throws IOException {

		ObjectOutputStream writer = new ObjectOutputStream(new FileOutputStream(FILENAME));

		for (FacebookClass nextUser : users) {
			writer.writeObject(nextUser);
		}

		writer.close();
	}// end write users
	/**
	 * method to display the option the user will choose from
	 * @return menu
	 */
	private static int displayMenu() {
		int menu = 0;
		OUT.println("\nMenu\n " + 
				"1. List Users \n" + 
				"2. Add a user \n" + 
				"3. Delete a user \n"+ 
				"4. Get Password Hint \n" + 
				"5. Quit \n");

		OUT.println("What would you like to do? \n");
		menu = IN.nextInt();
		IN.nextLine();
		return menu;
	}
	/**
	 * method to list the users
	 */
	private static final void listUsers() {
		OUT.println("Current Facebook users name:");
		for (FacebookClass nUser : users) {

			OUT.printf("%s \n", nUser);
		}

	} // end listUsers method
	/**
	 * methods to add a user to FacebookUser object	
	 * @throws Exception
	 */
	private static final void addUser() throws Exception {

		OUT.print("Enter the Facebook user's name (Enter to end): ");
		String name = IN.nextLine();  
/**
 * Check if there is no user added and check to see if the users ArrayList already contains 
 * a facebookUser object with that usernameand display error if it does
 * and if it is unique to prompt the user for a password and hint.
 */
		if (name.isEmpty()) {

			ERR.printf("No users added; bye \n");
			return;
		}
		for(FacebookClass i: users) {
			if (i.getUsername().equalsIgnoreCase(name)) {
				ERR.printf("...there's already a user with the name %s\n",name);
				return;
			}
		}

		OUT.printf("Enter %s's password: ", name);
		String pwd = IN.nextLine();

		OUT.printf("Enter a password hint for %s's password: ", name);
		String hint = IN.nextLine();

		// need to flush Scanner before next input
		IN.nextLine(); 
		// add new FacebookUser to users
		FacebookClass newUser = new FacebookClass(name,pwd);
		newUser.setPasswordHint(hint); 
		users.add(newUser );
	}// end addUser method
	/**
	 * method to delete a user from FacebookUser object	
	 */
	private static final void deleteUser() 
	{
		OUT.println("Enter the facebook user's name: ");
		String name = IN.nextLine();

		FacebookClass nextUser = findUser(name);

		/**
		 * checking to see that the users arraylist contains a facebookclass with that
 		username check that if Facebookclass object with this username has the same password
 		as the one entered if it doesn't display error message
		 */

		if (nextUser != null) {
			OUT.println("Enter the facebook user's password: ");
			String password = IN.nextLine();

			if (nextUser.getPassword().equals(password)) {
				users.remove(nextUser);
				OUT.printf("%s removed successfully%n", name);
			} else {
				ERR.println("Incorrect Password");
			}
		} else {
			ERR.printf("...there's no user with the name %s%n", name);

		}// end for each loop
	} // end deleteUser method

	/**
	 * method to get password hint
	 */
	private static final void getPasswordHint() {

		for (FacebookClass nUser : users) {

			OUT.println("Enter the facebook user's name:");
			String name = IN.nextLine();

			FacebookClass nextUser = findUser(name);
			if (nextUser != null) {
				OUT.printf("%s's hint is : ", nextUser.toString());
				nextUser.getPasswordHint();
			} else {
				ERR.printf("...there's no user with the name %s\n", name);
				break;
			}// end if else statement

		}// end for loop

	}//end getPasswordHint method

	/**
	 * method returns the first FacebookUser with
	 *   the given name, or null if there is no such
	 *   FacebookUser
	 *   
	 * @param name the given name (String)
	 * @return the 1st FacebookUser with the name, or null
	 */

	private static final FacebookClass findUser(String name) {
		FacebookClass result = null;

		for (FacebookClass nextUser : users) {
			if (nextUser.isNamed(name)) {
				result = nextUser;
				break; // end loop
			}
		} // end for each loop

		return result;
	} // end findUser method
	/**
	 * main method start
	 * @param args
	 * @throws Exception
	 * @throws ClassNotFoundException
	 */

	public static void main(String[] args) throws Exception, ClassNotFoundException {
		/**
		 * calling the readerUser method to deserializeand throws exception in caseclass not found
		 */
		try {
			readUsers();
		} catch (ClassNotFoundException | IOException e) {
			OUT.println(e.getMessage());
		}
		int choice;

		do {
			choice = displayMenu();

			switch (choice) {
			case 1:// List Users
				if (users.isEmpty()) {
					OUT.println("Can'list User, no user");
				} else {

					listUsers();
				}
				break;
			case 2: // Add a user

				addUser();

				break;
			case 3: // Delete a user
				OUT.println();
				deleteUser();
				break;
			case 4: // Get Password Hint
				OUT.println();
				getPasswordHint();
				break;
			case 5: // Quit

				OUT.println("Goodbye!");
				try { 
					writeUsers();
				}catch(IOException e)
				{ OUT.println(e.getMessage()); }
				break;
			default:// unknown option
				OUT.println("Sorry, " + choice + " was not one of the options.\n");

			}// end switch statement
		} while (choice != 5);// end do while loop

	}// end catch
}// end main method

// end FacebookDriver class
