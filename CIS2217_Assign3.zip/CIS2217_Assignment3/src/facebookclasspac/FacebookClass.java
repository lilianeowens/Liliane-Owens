package facebookclasspac;

import java.util.ArrayList;



@SuppressWarnings("serial")
public class FacebookClass extends UserAccountClass {
	/**
	 * Fields
	 */


	private String passwordHint;

	private ArrayList<FacebookClass> friends = new ArrayList<FacebookClass>();


	/**
	 * constructors
	 * @param username
	 * @param password
	 * @param new ArrayList<FacebookClass>() 
	 */

	public FacebookClass(String username, String password,boolean active, String passwordHint, ArrayList<FacebookClass> friends){
		super(username, password, active);
		this.passwordHint = passwordHint;
		this.friends = friends;

	}

	public FacebookClass(String username, String password) {
		super(username, password);
	}



	/**
	 * @return the passwordHint and output password hint 
	 */
	public String getPasswordHint() {
		System.out.println(passwordHint);
		return passwordHint;
	}

	/**
	 * @param passwordHint the passwordHint to set
	 */
	public void setPasswordHint(String hint) {
		this.passwordHint = hint;
	}

	/**
	 * @return the friends
	 */
	public ArrayList<FacebookClass> getFriends() {
		ArrayList<FacebookClass> friend = new ArrayList<FacebookClass>(friends);
		return friend;

	}

	/**
	 * @param friends the setter for friends 
	 */
	public void setFriends(ArrayList<FacebookClass> friends) {
		this.friends = friends;
	}
	public void friend(FacebookClass newFriend) {

		if ( (FacebookClass)newFriend != null) {
			friends.add(newFriend);
		}
		System.out.println(friends);	


	}
	public void deFriend(FacebookClass formerFriend) {

		friends.remove(formerFriend);

	}

	/**
	 * create the password hint
	 * 
	 */
	@Override
	public void getPasswordHelp() {

		setPasswordHint(getPasswordHint());

	}
	//print the object
	@Override
	public String toString() {

		return String.format("%s",super.getUsername() );
	}// end toString method
}//end FacebookClass method


