// Mugisha Liliane Abizera
// CIS 1111
// 6/27/2021
// Midterm Project
// This program is calculating the bmi and track the activity per week, 
//it also track your calories regarding on how you are active. 

#include<iostream>
#include<string> // needed for string variable and getline function
#include<cmath>// needed for power function

using namespace std;

int main()
{
	int age, weight, height;
		string gender ;
		int activity, calories;

		// The user is entering gender, height, weight,age.
		cout << "enter your gender: ";
		getline(cin, gender);
		cout << "Enter your height in inches: ";
		cin >> height;
		cout << "Enter the your age: ";
		cin >> age;
		cout << "Enter your weight: ";
		cin >> weight;

		// calculate the bmi
		int bmi = weight / pow(height, 2.0) * 703;
		cout << "Enter 1,2,3,4,5,6,7 depend on where do you place on regular basis exercise : ";
		cin >> activity;

		// telling the user to enter data he already knows by choice he wants
		// calculate bmi.
		switch (activity)
		{
		case 1: cout << "1.Basal Metalic Rate(BMR)" << endl;
			if (calories = weight * 13)
			{
				cout << "You do not exercise at all " << endl;
				cout << "You need to find fitness club to keep up with your weight or lose it" << endl;
			}
			if (bmi < 16)
			{
				cout << "You are severe thinness" << endl;
			}
			else if (bmi < 17)
			{
				cout << "you are moderate thinness" << endl;
			}
			else if (bmi < 19)
			{
				cout << "You are mild thinness" << endl;
			}
			else if (bmi < 26)
			{
				cout << "You are normal" << endl;
			}
			else if (bmi < 31)
			{
				cout << "you are overweight" << endl;
			}
			else if (bmi < 36)
			{
				cout << "You are obese class I" << endl;
			}
			else if (bmi < 41)
			{
				cout << "You are obese class II" << endl;
			}
			else
			{
				cout << "You are obese class III" << endl;
			}
			break;
		case 2: cout << "2.Sedentary little or no exercise " << endl;
			if (calories = weight * 13)
			{
				cout << "You do not exercise at all " << endl;
				cout << "You need to find fitness club to keep up with your weight or lose it" << endl;
			}
			if (bmi < 16)
			{
				cout << "You are severe thinness" << endl;
			}
			else if (bmi < 17)
			{
				cout << "you are moderate thinness" << endl;
			}
			else if (bmi < 19)
			{
				cout << "You are mild thinness" << endl;
			}
			else if (bmi < 26)
			{
				cout << "You are normal" << endl;
			}
			else if (bmi < 31)
			{
				cout << "you are overweight" << endl;
			}
			else if (bmi < 36)
			{
				cout << "You are obese class I" << endl;
			}
			else if (bmi < 41)
			{
				cout << "You are obese class II" << endl;
			}
			else
			{
				cout << "You are obese class III" << endl;
			}
			break;
		case 3: cout << "3.Light: exercise 1-3 times/week " << endl;
			if (calories = weight * 15)
			{
				cout << "You exercise 1 -3 times per week" << endl;
				cout << "Keep up you doing great " << endl;
			}
			if (bmi < 16)
			{
				cout << "You are severe thinness" << endl;
			}
			else if (bmi < 17)
			{
				cout << "you are moderate thinness" << endl;
			}
			else if (bmi < 19)
			{
				cout << "You are mild thinness" << endl;
			}
			else if (bmi < 26)
			{
				cout << "You are normal" << endl;
			}
			else if (bmi < 31)
			{
				cout << "you are overweight" << endl;
			}
			else if (bmi < 36)
			{
				cout << "You are obese class I" << endl;
			}
			else if (bmi < 41)
			{
				cout << "You are obese class II" << endl;
			}
			else
			{
				cout << "You are obese class III" << endl;
			}
			break;
		case 4: cout << "4.Moderate: exercise 4-5 times/week " << endl;
			if (calories = weight * 15)
			{
				cout << "You exercise 1 -3 times per week" << endl;
				cout << "Keep up you doing great " << endl;
			}
			if (bmi < 16)
			{
				cout << "You are severe thinness" << endl;
			}
			else if (bmi < 17)
			{
				cout << "you are moderate thinness" << endl;
			}
			else if (bmi < 19)
			{
				cout << "You are mild thinness" << endl;
			}
			else if (bmi < 26)
			{
				cout << "You are normal" << endl;
			}
			else if (bmi < 31)
			{
				cout << "you are overweight" << endl;
			}
			else if (bmi < 36)
			{
				cout << "You are obese class I" << endl;
			}
			else if (bmi < 41)
			{
				cout << "You are obese class II" << endl;
			}
			else
			{
				cout << "You are obese class III" << endl;
			}
			break;
		case 5: cout << "5.Active: daily exercise or intense exercise 3-4 times/week" << endl;
			if (calories = weight * 15)
			{
				cout << "You exercise 1 -3 times per week" << endl;
				cout << "Keep up you doing great " << endl;
			}
			if (bmi < 16)
			{
				cout << "You are severe thinness" << endl;
			}
			else if (bmi < 17)
			{
				cout << "you are moderate thinness" << endl;
			}
			else if (bmi < 19)
			{
				cout << "You are mild thinness" << endl;
			}
			else if (bmi < 26)
			{
				cout << "You are normal" << endl;
			}
			else if (bmi < 31)
			{
				cout << "you are overweight" << endl;
			}
			else if (bmi < 36)
			{
				cout << "You are obese class I" << endl;
			}
			else if (bmi < 41)
			{
				cout << "You are obese class II" << endl;
			}
			else
			{
				cout << "You are obese class III" << endl;
			}
			break;
		case 6: cout << "6.Very active: intense exercise 6-7 times/week" << endl;
			if (calories = weight * 18)
			{
			cout << "You exercise five days or more a week " << endl;
			cout << "You will reach your goal " << endl;
			}
			if (bmi < 16)
			{
				cout << "You are severe thinness" << endl;
			}
			else if (bmi < 17)
			{
				cout << "you are moderate thinness" << endl;
			}
			else if (bmi < 19)
			{
				cout << "You are mild thinness" << endl;
			}
			else if (bmi < 26)
			{
				cout << "You are normal" << endl;
			}
			else if (bmi < 31)
			{
				cout << "you are overweight" << endl;
			}
			else if (bmi < 36)
			{
				cout << "You are obese class I" << endl;
			}
			else if (bmi < 41)
			{
				cout << "You are obese class II" << endl;
			}
			else
			{
				cout << "You are obese class III" << endl;
			}
			break;
		case 7: cout << "7.Extra Active: very intense exercise daily, or physical job." << endl;
			if (calories = weight * 18)
			{
				cout << "You exercise five days or more a week " << endl;
				cout << "You will reach your goal keep up" << endl;
			}
			if (bmi < 16)
			{
				cout << "You are severe thinness" << endl;
			}
			if (bmi < 16)
			{
				cout << "You are severe thinness" << endl;
			}
			else if (bmi < 17)
			{
				cout << "you are moderate thinness" << endl;
			}
			else if (bmi < 19)
			{
				cout << "You are mild thinness" << endl;
			}
			else if (bmi < 26)
			{
				cout << "You are normal" << endl;
			}
			else if (bmi < 31)
			{
				cout << "you are overweight" << endl;
			}
			else if (bmi < 36)
			{
				cout << "You are obese class I" << endl;
			}
			else if (bmi < 41)
			{
				cout << "You are obese class II" << endl;
			}
			else
			{
				cout << "You are obese class III" << endl;
			}
			break;
		default:cout << "You did not select any number 1,2,3,4,5,6,7!" << endl;
}
		
		return(0);

}
