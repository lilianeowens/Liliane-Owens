/*Mugisha Liliane Abizera
CIS 1111
12/7/2021
Functions Assignment */

#include<iostream>
#include<iomanip>
#include<string>

using namespace std;

void showMenu()
{
	cout << "Greek Islands Menu:\n";
	cout << "1. Gyro      " << " $7.00\n";
	cout << "2. Moussaka  " << " $8.50\n";
	cout << "3. salad    " << "  $3.75\n";
	cout << "4. Dolma    " << "  $2.00\n";
	cout << "5. Soda     " << "  $2.80\n";
	cout << "6. Cofee     " << " $1.00\n";
	cout << "7. Water      " << "$2.00\n";
	cout << "8. End order             \n";

}
void displayBill(float bill, float totalBill, float tax, float tip)
{
	cout << setprecision(2) << fixed;
	cout << "Bill =      " <<setw(4)  << "$" << bill << endl;
	cout << "Tax =       " << setw(5) << "$" << tax << endl;
	cout << "tip =       " << setw(5) << "$" << tip << endl;
	cout << "totalBill = " << setw(4) << "$" << tax + bill + tip << endl;
}
void displayChangedue(float totalBill, float Pymt)
{
	float change = totalBill - Pymt;
	cout << setprecision(2) << fixed;
	cout << "Amount tendered =  " << setw(4) << "$" << Pymt << endl;
	cout << "Change due=        " << setw(4) << "$" << change << endl;
}


int main()
{
	int choice; // To hold a menu choice
	float total = 0.0; // accumulator

	//constants for the menu choice
	const int Gyro_choice = 1,
		      Moussaka_choice = 2,
			  salad_choice = 3,
			  Dolma_choice = 4,
			  Soda_choice = 5,
		      Cofee_choice = 6,
		      Water_choice = 7,
		      EndOrder_choice = 8;

	//constants for the prices rates
	const float Gyro = 7.00,
		Moussaka = 8.50,
		salad = 3.75,
		Dolma = 2.00,
		Soda = 2.80,
		Cofee = 1.00,
		Water = 2.00;
	double Pymt{};
	float bill{}, totalBill{}, tax{}, tip{};

	const float taxRate = 0.065, tipRate = 0.20;

	showMenu();

	do {
		cout << "enter the menu item: ";
		cin >> choice;
		while (choice < Gyro_choice || choice > EndOrder_choice)
		{
			cout << "Incorrect number, Please reenter menu item 8\n";
			cin >> choice;
	    }

		switch (choice)
		{
		case 1:
			total += Gyro;
			break;
		case 2: total += Moussaka;
			break;
		case 3: total += salad;
			break;
		case 4: total += Dolma;
			break;
		case 5: total += Soda; 
			break;
		case 6: total += Cofee;
			break;
		case 7: total += Water;
			break;
		}

	} while ( choice != EndOrder_choice);

	//calculate tax and tip and grand total
	
	tax = total * taxRate;
	tip = total* tipRate;
	totalBill = total + tax + tip;

	//call the displayBill function
	displayBill(totalBill, bill, tax, tip);
	cout << "\nEnter the payment :$ ";
	cin >> Pymt;
	displayChangedue(Pymt, totalBill);

	return 0;
}