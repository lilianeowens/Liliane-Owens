//import java.util.Scanner;

public class MenuDrivenCalculator {

public static void main(String[] args) {

//		Scanner input = new Scanner(System.in);
//
//		int count=0, // counter
//			choice;
//		double 	firstNumber,
//				secondNumber,
//				answer,
//				lowerLimit,
//				upperLimit;
//		for (int i = 0; i <= 3; i++) {
//			System.out.println(i);
//			}			
		//int x = 23;
//		if (x >= 23) {
//		    System.out.println ("Hello");
//		} else {
//		    System.out.println ("Goodbye");
//		}
//		for (int i=10;  i>0;  i--)  {
//		     if (i % 2 == 1)  {
//		           break;
//		     }
//		     System.out.println("Hello");
//		}
//		
//		int x = 3;
//		switch (x)  {
//		     case 1: System.out.println("x is 1");
//		     case 2: System.out.println("x is 2");
//		     case 3: System.out.println("x is 3");
//		     case 4: System.out.println("x is 4");
//		     default: System.out.println("unknown x");
//		}
		//public class Example {
//			   public static void swap(int x, int y) {
//			        int temp = y;
//			        y = x;
//			        x = temp;
//			   }
//			 
//			public static void main(String[] args) {
//			        int x = 1;
//			        int y = 2;
//			        swap (x, y);
//			        System.out.println("x = " + x + " and y = " + y);   }
//}
	//public class Example  {
//	     public static void methodA(int a)  {
//	          System.out.println("at location1");
//	     }
//	public static void methodA(double a)  {
//	          System.out.println("at location 2");
//	     }
//
//	public static void main(String[] args)  {
//	          methodA(2);
//	     }
//
//	}
	 int[] myArray = {1, 3, 17, 4, 2, 42};
	 System.out.println(myArray[2]);
//		do {
//
//               System.out.print(
//	            		" Menu\n" + 
//						" 1. Add\n" + 
//						" 2. Substract\n" +
//						" 3. Multiply\n" +
//						" 4. Didide\n " +
//						" 5. Generate random number\n" +
//						" 6. Quit\n\n");
//		
//               //Prompt the user to select a choice
//               count++;
//			
//		System.out.print("What would you like to do? ");
//		
//		choice = input.nextInt();
//
//			switch (choice) 
//			{
//			
//			case 1://Add
//				
//					System.out.println("What is the first number?");
//					firstNumber = input.nextDouble();
//					System.out.println("What is the second number ?");
//					secondNumber = input.nextDouble();
//					answer = firstNumber + secondNumber;
//					System.out.println("Answer : " + answer);
//					break;
//
//			case 2: // Subtract
//				
//					System.out.println("What is the first number?");
//					firstNumber = input.nextDouble();
//					System.out.println("What is the second number?");
//					secondNumber = input.nextDouble();
//					answer = firstNumber - secondNumber;
//					System.out.println("Answer : " + answer);
//					break;
//
//			case 3://Multiply
//				
//					System.out.println("What is the first number?");
//					firstNumber = input.nextDouble();
//					System.out.println("What is the second number?");
//					secondNumber = input.nextDouble();
//					answer = firstNumber * secondNumber;
//					System.out.println("Answer : " + answer);
//					break;
//
//			case 4: //Divide
//				
//					System.out.println("What is the first number?");
//					firstNumber = input.nextDouble();
//					System.out.println("What is the second number?");
//					secondNumber = input.nextDouble();
//	
//					if (secondNumber == 0) {
//						System.out.println("I'm sorry you can't divide by zero.\n" + "Answer: naN ");
//						break;
//					}
//					answer = firstNumber / secondNumber;
//	
//					System.out.println("Answer : " + answer);
//					break;
//
//			case 5:// Generate the random Number
//				
//					System.out.println("What is the lower limit?");
//					lowerLimit = input.nextDouble();
//					System.out.println("What is the upper limit ?");
//					upperLimit = input.nextDouble();
//					answer = lowerLimit + Math.random() * (upperLimit - lowerLimit);
//					System.out.println("Answer : " + answer);
//					break;
//
//			case 6:// Quit
//				
//					System.out.println("Goodbye!");	
//					break;
//			default :
//
//					System.out.println("I am sorry, " + choice + " was not one of the options.");
//					break;
//
//			}
//
//
//		}while(count < 3);
//
//		System.out.println("Please try again Later");	
//
//
//		// End the first loop start the second loop  
//		
//		System.out.print("\n --------------------------------------------------------------\n");
//
//
//		do 
//		{
//
//				System.out.print(
//								" Menu\n" + 
//								" 1. Add\n" + 
//								" 2. Substract\n" +
//								" 3. Multiply\n" + 
//								" 4. Didide\n " + 
//								" 5. Generate random number \n" +
//								" 6. Quit\n\n");
//
//			System.out.println(" What would you like to do? (the input ends if it is 6):");
//			choice =input.nextInt();
//
//			switch (choice)
//			{ 
//
//			case 1:// Add
//					System.out.println("What is the first number?");
//					firstNumber = input.nextDouble(); 
//					System.out.println("What is the second number ?");
//					secondNumber = input.nextDouble(); 
//					answer = firstNumber + secondNumber;
//					System.out.println("Answer : " + answer); 
//					break;
//
//			case 2: // Subtract 
//
//					System.out.println("What is the first number?");
//					firstNumber = input.nextDouble();
//					System.out.println("What is the second number?");
//					secondNumber = input.nextDouble(); 
//					answer = firstNumber - secondNumber;
//					System.out.println("Answer : " + answer); 
//					break;
//
//			case 3:// Multiply 
//					
//					System.out.println("What is the first number?");
//					firstNumber = input.nextDouble();
//					System.out.println("What is the second number?");
//					secondNumber = input.nextDouble(); 
//					answer = firstNumber * secondNumber;
//					System.out.println("Answer : " + answer); 
//					break;
//
//			case 4: // Divide 
//
//					System.out.println("What is the first number?");
//					firstNumber = input.nextDouble();
//					System.out.println("What is the second number?"); 
//					secondNumber = input.nextDouble();
//	
//					if (secondNumber == 0) {
//						System.out.println("I'm sorry you can't divide by zero.\n" + "Answer: NaN ");
//						break; 
//						} 
//					answer = firstNumber / secondNumber;
//
//					System.out.println("Answer : " + answer); 
//					break;
//
//			case 5: // Generate random number
//
//				   System.out.println("What is the lower limit?"); 
//				   lowerLimit = input.nextDouble(); 
//				   System.out.println("What is the upper limit ?");
//				   upperLimit = input.nextDouble(); 
//				   answer = lowerLimit + Math.random() *(upperLimit - lowerLimit); 
//				   System.out.println("Answer : " + answer); 
//				   break;
//
//			case 6:// Quit 
//				   System.out.println("Goodbye!"); 
//			       break;
//
//			default :
//
//                     System.out.println("I am sorry, " + choice + " was not one of the options.");
//
//			}
//
//		}while(choice != 6);
//
//		input.close();
//

}
}
