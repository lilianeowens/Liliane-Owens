// Mugisha Liliane Abizera
// 6/21/2021
// CIS 1111
// Relationnal operators

#include<iostream>
#include<string>
#include <cmath>
using namespace std;

int main()
{
	int nBRoom, monthlyIncome;
	cout << "Your monthly income is : ";
	cin >> monthlyIncome;
	float grossIncome = monthlyIncome * 0.40;
	
	cout << "Enter 1 if you want one bedroom or 2 for a two bedroom:";
	cin >> nBRoom;
	
	switch (nBRoom)
	{
	case 1: cout << "You entered 1." << endl;
		

		if (grossIncome >= 1225)
		{
			cout << "You qualify for one bedroom by the river without utilities " << endl;
			cout << "To get utilities you need to add 50$ to the regular price. " << endl;
		}
		else if (grossIncome >= 700)
		{
			cout << "You qualify for one bedroom close to the river with utilities " << endl;
		}
		else if (grossIncome >= 500)
		{
			cout << "You qualify for one bedroom far from the river with utilities " << endl;
		}
		else
		{
			float roomtemp = 500/ grossIncome;
			int roommates = ceil(roomtemp);
			cout << "If you want to live downtown you need to get:" << roommates << " roommate(s)" << endl;
		}
		
		break;
	case 2: cout << "You entered 2." << endl;

		if (grossIncome >= 1750)
		{
			cout << "You qualify for two bedroom by the river without utilities " << endl;
			cout << "To get utilities you need to add 50$ to the regular price. " << endl;
		}
		else if (grossIncome >= 1200)
		{
			cout << "You qualify for two bedroom close to the river with utilities " << endl;
		}
		else if (grossIncome >= 800)
		{
			cout << "You qualify for two bedroom far from the river with utilities " << endl;
		}
		else
		{
			float roomtemp = 800 / grossIncome;
			int roommates = ceil(roomtemp);
			cout << "If you want to live downtown you need to get:" << roommates << " roommate(s)" << endl;
		}
		break;
	default: cout << "You did not enter 1 or 2 ." << endl;
	}
	
	
		return (0);
	}