// Mugisha Liliane Abizera
// May 25, 2021
// Computer Science
// This program will output the first name, major, number of credit hours, and per credit hour tuition rate

#include <iostream>
using namespace std;
int main()
{

int credit;
	credit = 6;

string majorName;
	majorName = "computer science";

string name;
	name = "Mugisha";

float price;
	price =  99.03;

 cout << "My name is " << name << endl;          // ask the user for his/her name
cout << "I am majoring in " << majorName << endl;   // ask the user his/her major
cout << "The number of credit am taking is " << credit << endl;      // ask the user how many credit he/she is taking
cout << "My pay rate per credit hour is $" << price << endl << endl;    // ask the user the tuition rate per credit hour

system("pause");
return 0;

}