package libraryguijavafx;

public class MediaItem {
	private String title,
	format,
	loanedTo,
	dateLoaned;

	private boolean onLoan;

	public MediaItem() {
		this(null, null, false, null, null);
	}

	public MediaItem(String title, String format) {
		this(title, format, false, null, null);
	}

	public MediaItem(String title, String format, boolean onLoan, String loanedTo, String dateLoaned) {
		this.title = title;
		this.format = format;
		this.onLoan = onLoan;
		this.loanedTo = loanedTo;
		this.dateLoaned = dateLoaned;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public void setLoanedTo(String loanedTo) {
		this.loanedTo = loanedTo;
	}

	public void setDateLoaned(String dateLoaned) {
		this.dateLoaned = dateLoaned;
	}

	public void setOnLoan(boolean onLoan) {
		this.onLoan = onLoan;
	}

	public String getTitle() {
		return title;
	}

	public String getFormat() {
		return format;
	}

	public String getLoanedTo() {
		return loanedTo;
	}

	public String getDateLoaned() {
		return dateLoaned;
	}

	public boolean getOnLoan() {
		return onLoan;
	}

	public void markOnLoan(String name, String date) throws IllegalArgumentException {
		if(onLoan == true) {
			String msg = String.format("%s is already on loan to %s.", title, loanedTo);

			throw new IllegalArgumentException(msg);
		}
		else {
			onLoan = true;
			loanedTo = name;
			dateLoaned = date;
		}
	}

	public void markReturned() throws IllegalArgumentException {
		if(onLoan == true) {
			onLoan = false;
			loanedTo = null;
			dateLoaned = null;
		}
		else {
			String msg = String.format("%s is not currently on loan.", title);

			throw new IllegalArgumentException(msg);
		}
	}
}


