package libraryguijavafx;

import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import java.io.FileNotFoundException;
import java.io.IOException;
import javafx.collections.*;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;


public class LibraryGui1 extends Application {
	private Library library;
	private ListView <String>lv = new ListView<>();
	private VBox vBox;
	private String inPut1;
	private String inPut2;

	private ObservableList<String> list;

	public LibraryGui1 () { 
		library = new Library();
		try { 
			library.open(); } 
		catch(IOException ex) { Alert alert = new
				Alert(AlertType.ERROR);
		alert.setContentText("There was a problem accessing the library.");
		alert.showAndWait();

		System.exit(1); } }

	@Override
	public void start(Stage primaryStage) throws Exception {
		GridPane listPane = new GridPane();
		listPane.setPadding(new Insets(15,15,10,15));

		// creates four columns at 25% ration of the window
		// Allows the list to stretch horizontally when you stretch
		for(int i =0; i< 4;i++)  {
			ColumnConstraints column = new ColumnConstraints();
			column.setPercentWidth(25);
			listPane.getColumnConstraints().add(column);
		}
		// GridPane to hold the buttons
		GridPane buttonPane = new GridPane();
		buttonPane.setAlignment(Pos.CENTER);
		buttonPane.setPadding(new Insets(5,15,15,15));
		buttonPane.setHgap(15);
		buttonPane.setVgap(15);

		vBox = new VBox(listPane, buttonPane);
		vBox.setVgrow(listPane, Priority.ALWAYS);

		list = FXCollections.observableArrayList(library.listAllItems());
		lv = new ListView<String>(list);
		lv.prefHeightProperty().bind(vBox.heightProperty());

		Button Add = new Button("Add");	  
		Button CheckOut = new Button("CheckOut");
		Button CheckIn = new Button("CheckIn");	
		Button Delete = new Button("Delete");	

		listPane.add(lv, 0, 0, 4, 1);
		buttonPane.add(Add, 0, 0);
		buttonPane.add(CheckOut, 1, 0);
		buttonPane.add(CheckIn, 2, 0);
		buttonPane.add(Delete, 3, 0);

		Add.setOnAction(e -> {
			add();  
		});

		CheckOut.setOnAction(e -> {
			checkOut();  
		});
		CheckIn.setOnAction(e -> {
			checkIn();  
		}); 
		Delete.setOnAction(e -> {
			delete();  
		});

		// Create a scene and place it in the stage
		Scene scene = new Scene(vBox);
		primaryStage.setTitle("Personnal Library Lending"); // Set the stage title
		primaryStage.setScene(scene); // Place the scene in the stage
		primaryStage.show(); // Display the stage

	}

	@Override 
	public void stop() { 
		try { 
			library.save();
		}
		catch(FileNotFoundException ex) { 
			Alert alert = new Alert(AlertType.ERROR);
			alert.setContentText("There was a problem accessing the library.");
			alert.showAndWait();
		}
	}
	private void inPut(String msg1, String msg2, String methodSelector, boolean additionalInPut, String title) {
		// Stage used for additional window
		Stage messageStage = new Stage();
		GridPane gpane = new GridPane();
		gpane.setAlignment(Pos.CENTER);
		gpane.setPadding(new Insets(25,25,25,25));
		gpane.setHgap(20);
		gpane.setVgap(2);

		ColumnConstraints imageColumn = new ColumnConstraints();
		ColumnConstraints messageColumn = new ColumnConstraints();
		imageColumn.setPercentWidth(25);
		messageColumn.setPercentWidth(75);
		gpane.getColumnConstraints().addAll(imageColumn, messageColumn);

		Button OK = new Button("Ok");
		gpane.add(OK,0,2);

		Button cancel = new Button("cancel");
		gpane.add(cancel,1,2);
		Label label = new Label(msg1);
		gpane.add(label, 0, 0);
		TextField textField = new TextField();

		gpane.add(textField, 0, 1);

		// cancel button will close window

		cancel.setOnAction(e -> messageStage.hide());
		// OK button used to proceed

		OK.setOnAction(e-> {
			// textField.setText("");
			inPut2 = textField.getText();
			if(additionalInPut == true) {
				inPut1 = inPut2;
				inPut(msg2, null, methodSelector, false, title);
			}
			else {
				if (methodSelector.equals("Add")) {
					library.addNewItem(inPut1, inPut2);
					list = FXCollections.observableArrayList(library.listAllItems());
					lv.setItems(list);
				}
				else  if (methodSelector.equals("Check out")) {
					library.markItemOnLoan(title,inPut1, inPut2);

					list = FXCollections.observableArrayList(library.listAllItems());
					lv.setItems(list);
				}
			}
			messageStage.hide();
		});
		// Format and display the stage

		Scene scene = new Scene(gpane, 400,150);
		messageStage.initModality(Modality.WINDOW_MODAL);
		messageStage.initOwner(vBox.getScene().getWindow());
		messageStage.setTitle("Input");
		messageStage.setScene(scene);
		messageStage.setResizable(false);
		messageStage.show();
	}


	// Call inPut() method with the Add argument 
	private void add() {
		inPut("Title:", "Format:", "Add", true, null);
	}

	private void checkOut() {
		if(lv.getSelectionModel().getSelectedItem()== null) {
			return;
		}
		Object selected =lv.getSelectionModel().getSelectedItem();  // gets the selected item
		String s = selected.toString(); // converts that to a String
		String title = s.substring(0, s.lastIndexOf("(")); // extracts the title
		title = title.trim(); // removes any trailing whitespace
		try {
			library.checkLoanStatus(title);
		}
		catch(IllegalArgumentException ex) {
			message(ex.getMessage());
			return;
		}
		inPut("Who did you loan this to?" , "When did you loan it?(Date)","Check out", true, title);
	}

	private void checkIn() {
		if(lv.getSelectionModel().getSelectedItem()== null) {
			return;
		}
		Object selected =lv.getSelectionModel().getSelectedItem();  // gets the selected item
		String s = selected.toString(); // converts that to a String
		String title = s.substring(0, s.lastIndexOf("(")); // extracts the title
		title = title.trim(); // removes any trailing whitespace
		try {
			library.markItemReturned(title);
		}
		catch(IllegalArgumentException ex) {
			message(ex.getMessage());
			return;
		}
		list = FXCollections.observableArrayList(library.listAllItems());
		lv.setItems(list);
	}

	private void delete() {
		if(lv.getSelectionModel().getSelectedItem()== null) {
			return;
		}
		Object selected =lv.getSelectionModel().getSelectedItem();  // gets the selected item
		String s = selected.toString(); // converts that to a String
		String title = s.substring(0, s.lastIndexOf("(")); // extracts the title
		title = title.trim(); // removes any trailing whitespace

		library.deleteItem(title);
		list = FXCollections.observableArrayList(library.listAllItems());
		lv.setItems(list);
	}
	private void message(String msg) {
		// Stage used for additional window
		Stage messageStage = new Stage();
		// GridPane and formatting used to hold our nodes
		GridPane pane = new GridPane();
		pane.setAlignment(Pos.CENTER);
		pane.setPadding(new Insets(25,25,25,25));
		// Creates nodes needed for message window
		Label label = new Label(msg);
		Button OK = new Button("OK");
		GridPane.setHalignment(label,HPos.CENTER);
		GridPane.setHalignment(OK, HPos.CENTER);
		GridPane.setValignment(OK, VPos.BOTTOM);

		// Formats nodes
		label.setWrapText(true);
		OK.setMinSize(100, 25);
		OK.setDefaultButton(true);
		// Places nodes on GridPane
		pane.add(label, 1,1);
		pane.add(OK, 1, 2);

		OK.setOnAction(e ->messageStage.hide());
		Scene scene = new Scene(pane, 400,150);
		messageStage.initModality(Modality.WINDOW_MODAL);
		messageStage.initOwner(vBox.getScene().getWindow());
		messageStage.setTitle("Message");
		messageStage.setScene(scene);
		messageStage.setResizable(false);
		messageStage.show();
	}
	public static void main(String[] args) {
		launch(args);
	}
}
