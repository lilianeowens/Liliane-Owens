package libraryguijavafx;

import java.util.ArrayList;

public class Library {
	private ArrayList<MediaItem> items;
	private String fileName;

	public Library() {
		items = new ArrayList<MediaItem>();
		fileName = "library.txt";
	}

	public void setItems(ArrayList<MediaItem> items) {
		this.items.clear();

		for(MediaItem i : items) {
			this.items.add(i);
		}
	}

	public ArrayList<MediaItem> getItems() {
		return items;
	}

	public void setFile(String fileName) {
		this.fileName = fileName;
	}

	public String getFileName() {
		return fileName;
	}

	public void addNewItem(String title, String format) {
		items.add(new MediaItem(title, format));
	}

	public void deleteItem(String title) {
		for(int i = 0; i < items.size(); i++) {
			if(items.get(i).getTitle().equalsIgnoreCase(title)) {
				items.remove(i);
			}
		}
	}

	public void checkLoanStatus(String title) {
		for(int i = 0; i < items.size(); i++) {
			if(items.get(i).getTitle().equalsIgnoreCase(title)) {
				if(items.get(i).getOnLoan()) {
					String msg = String.format("%s is already on loan to %s.", items.get(i).getTitle(), items.get(i).getLoanedTo());

					throw new IllegalArgumentException(msg);
				}
			}
		}
	}

	public void markItemOnLoan(String title, String name, String date) {
		for(int i = 0; i < items.size(); i++) {
			if(items.get(i).getTitle().equalsIgnoreCase(title)) {
				items.get(i).markOnLoan(name, date);
			}
		}
	}

	public void markItemReturned(String title) {
		for(int i = 0; i < items.size(); i++) {
			if(items.get(i).getTitle().equalsIgnoreCase(title)) {
				items.get(i).markReturned();
			}
		}
	}

	public ArrayList<String> listAllItems() {
		ArrayList<String> list = new ArrayList<String>();

		for(int i = 0; i < items.size(); i++) {
			if(items.get(i).getOnLoan()) {
				list.add(String.format("%s (%s) loaned to %s on %s.",
						items.get(i).getTitle(), items.get(i).getFormat(), 
						items.get(i).getLoanedTo(), items.get(i).getDateLoaned()));
			}
			else {
				list.add(String.format("%s (%s)", items.get(i).getTitle(), items.get(i).getFormat()));
			}
		}

		return list;
	}

	public void save() throws java.io.FileNotFoundException {
		java.io.File file = new java.io.File(fileName);

		try(java.io.PrintWriter output = new java.io.PrintWriter(file)) {
			for(MediaItem i : items) {
				output.printf("%s|%s|%b|%s|%s|%n", i.getTitle(), i.getFormat(), i.getOnLoan(),
						i.getLoanedTo(), i.getDateLoaned());
			}
		}
	}

	public void open() throws java.io.FileNotFoundException, java.io.IOException {
		String title = null,
				format = null,
				loanStatus = null,
				loanedTo = null,
				dateLoaned = null;

		boolean onLoan = false;

		items.clear();

		java.io.File file = new java.io.File(fileName);

		if(!file.exists()) {
			file.createNewFile();
		}

		try(java.util.Scanner input = new java.util.Scanner(file)) {
			while(input.hasNextLine()) {
				title = input.useDelimiter("\\|").next();
				format = input.useDelimiter("\\|").next();
				loanStatus = input.useDelimiter("\\|").next();
				loanedTo = input.useDelimiter("\\|").next();
				dateLoaned = input.useDelimiter("\\|").next();
				input.nextLine();

				if(loanStatus.equalsIgnoreCase("true")) {
					onLoan = true;
				} else {
					onLoan = false;
				}

				items.add(new MediaItem(title, format, onLoan, loanedTo, dateLoaned));
			}
		}
	}
}
