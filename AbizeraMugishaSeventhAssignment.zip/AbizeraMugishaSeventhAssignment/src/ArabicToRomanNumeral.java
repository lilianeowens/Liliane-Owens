
import java.util.Scanner;


public class ArabicToRomanNumeral {


	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int  arabic;	

		// do while which prompt the user to enter the number between
		//the range 1-3999	and allow him to quit if he enter -1
		do {

			System.out.print(" Enter an integer  (-1 to quit): ");

			arabic = input.nextInt();
			String roman1 =  arabicToRoman(arabic);

			//Error message for entering number under >= 0
			if (arabic < 1 ) {
				System.out.println("The Romans didnot have a way to represent negative numbers or zero");
			}

			// Error message when the user enter the number > 3999
			else if(arabic > 3999) {
				System.out.println("Please enter the number between 1 and 3999");
			} 
			// Otherwise print the Roman number corresponding with the number you entered
			else

				System.out.println(roman1);

		}while(arabic != -1);	// when you enter -1 you quit	
		System.out.println("Goodbye!");
		input.close();
	}

	// The method to convert the Arabic to Roman numerals
	public static String arabicToRoman (int arabic) {

		int [] values = {1,4,5,9,10,40,50,90,100,400,500,900,1000};
		String [] roman = {"I","IV","V","IX","X","XL","L","XC","C","CD","D","CM","M"}; 
		StringBuilder sb = new StringBuilder();

		for (int i = values.length-1; i >= 0 && arabic > 0; i--) {
			while (arabic >= values[i]) {
				arabic -= values[i];
				sb.append(roman[i]);

			}
		}
		return sb.toString();
	}
}

