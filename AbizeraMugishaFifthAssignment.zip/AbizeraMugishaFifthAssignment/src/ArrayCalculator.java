import java.util.Scanner;

public class ArrayCalculator {

	public static void main(String[] args) {
		Scanner inKeyboard = new Scanner(System.in);

		int choice = 0;
		int size = 0;

		double[] operand1 = new double[size];
		double[] operand2 = new double[size];
		double[] result = new double[size];

		double dotProductResult = 0;
		double lowerLimit = 0;
		double upperLimit = 0;

		String firstMessage = "Enter the values in the first array, separated by spaces: ";
		String secondMessage = "Enter the values in the second array, separated by spaces: ";
		String lowerMessage = "What is the lower limit for the random number? ";
		String upperMessage = "What is the upper limit for the random number? ";

		do {
			choice= getMenuOption(size);

			switch (choice) { 
			
			case 1:// Add
				System.out.print("How many values are in the arrays? ");
				size = inKeyboard.nextInt();

				operand1 = getOperand(firstMessage, size);
				operand2 = getOperand(secondMessage, size);

				result = add(operand1, operand2);

				break;
			
			case 2: // Subtract 
				System.out.print("How many values are in the arrays? ");
				size = inKeyboard.nextInt();

				operand1 = getOperand(firstMessage, size);
				operand2 = getOperand(secondMessage, size);

				result = subtract(operand1, operand2);

				break;
			
			case 3:// Multiply 
				System.out.print("How many values are in the arrays? ");
				size = inKeyboard.nextInt();

				operand1 = getOperand(firstMessage, size);
				operand2 = getOperand(secondMessage, size);

				result = multiply(operand1, operand2);

				break;
			
			case 4: // Divide 
				System.out.print("How many values are in the arrays? ");
				size = inKeyboard.nextInt();

				operand1 = getOperand(firstMessage, size);
				operand2 = getOperand(secondMessage, size);

				result = divide(operand1, operand2);

				break;
			
			case 5: // Dot Product
				System.out.print("How many values are in the arrays? ");
				size = inKeyboard.nextInt();

				operand1 = getOperand(firstMessage, size);
				operand2 = getOperand(secondMessage, size);

				dotProductResult = dotProduct(operand1, operand2);

				System.out.println("The result is " + dotProductResult + "\n"); 

				break;
			
			case 6: // Generate random number
				System.out.print("How many values should be in the random array? ");
				size = inKeyboard.nextInt();

				lowerLimit = getOperand(lowerMessage);
				upperLimit = getOperand(upperMessage);

				result = random(lowerLimit, upperLimit, size);

				System.out.print("The result is [");

				for (int i = 0; i < size; i++) {
					System.out.print(result[i]);

					if (i != size - 1) {
						System.out.print(", ");
					}
				}

				System.out.println("]\n");

				break;
			
			case 7:// Quit 
				System.out.println("Goodbye!"); 
				break;
			
			default:
				System.out.println("I am sorry, " + choice + " was not one of the options.\n");
			}
		} while (choice != 7);

		inKeyboard.close();

	}	



	public static int getMenuOption(int choice) {
		int menu = 0;

		Scanner input = new Scanner(System.in);	

		System.out.print(
				" Menu\n" + 
						" 1. Add\n" + 
						" 2. Substract\n" +
						" 3. Multiply\n" + 
						" 4. Didide\n " + 
						" 5. Dot product\n " +
						" 6. Generate random number \n" +
				        " 7. Quit\n\n");

		System.out.print("What would you like to do? ");

		menu =input.nextInt();
		return menu;
	}

	public static double[] getOperand(String prompt, int size) {
		Scanner inKeyboard = new Scanner(System.in);

		double[] doublearray = new double[size];
		System.out.println(prompt);

		for (int i = 0; i < size; i++) {
			doublearray[i] = inKeyboard.nextDouble();
		}

		return doublearray;

	}

	public static double getOperand(String prompt) {
		Scanner in = new Scanner(System.in);
		System.out.print(prompt);

		double result = in.nextDouble();

		return result;
	}

	public static double[] add(double[] operand1, double[] operand2) {

		int size = operand1.length;

		double[] result = new double[size];
		System.out.print("The result is [");

		for (int i = 0; i < size; i++) {
			result[i] = operand1[i] + operand2[i];
			
				System.out.print(result[i]);

				if (i != size - 1) {
					System.out.print(", ");
				}
			}

			System.out.println("]\n");
		

		return result;	

	}

	public static double[] subtract(double[] operand1, double[] operand2) {

		int size = operand1.length;

		double[] result = new double[size];
		System.out.print("The result is [");

		for (int i = 0; i < size; i++) {
			result[i] = operand1[i] - operand2[i];
			
				System.out.print(result[i]);

				if (i != size - 1) {
					System.out.print(", ");
				}
			}

			System.out.println("]\n");
		

		return result;	

	}

	public static double[] multiply(double[] operand1, double[] operand2) {

		int size = operand1.length;

		double[] result = new double[size];
		System.out.print("The result is [");


		for (int i = 0; i < size; i++) {
			result[i] = operand1[i] * operand2[i];
			
			
				System.out.print(result[i]);

				if (i != size - 1) {
					System.out.print(", ");
				}
			}

			System.out.println("]\n");
		

		return result;	

	}

	public static double[] divide(double[] operand1, double[] operand2) {

		int size = operand1.length;

		double[] result = new double[size];
		System.out.print("The result is [");

		for (int i = 0; i < size; i++) {
			result[i] = operand1[i] / operand2[i];
			if (operand2[i] == 0) {
				result[i] = Double.NaN;
			
				System.out.print(" NaN ");}
			else 
				System.out.print(result[i]);
			if (i != size - 1) {
				System.out.print(", ");

			}
		}

		System.out.println("]\n");	
		
		return result;
	}
	public static double dotProduct(double[]operand1, double[] operand2) {
		int size = operand1.length;

		double dotProductResult = 0;

		for (int i = 0; i < size; i++) {
			dotProductResult += operand1[i] * operand2[i];
		}

		return dotProductResult;
	}

	public static double[] random(double lowerLimit, double upperLimit, int size) {
		double[] result = new double[size];
		double range = upperLimit - lowerLimit;

		for (int i = 0; i < size; i++ ) {
			result[i] = (Math.random() * range) + lowerLimit;
		}

		return result;
	}
}


