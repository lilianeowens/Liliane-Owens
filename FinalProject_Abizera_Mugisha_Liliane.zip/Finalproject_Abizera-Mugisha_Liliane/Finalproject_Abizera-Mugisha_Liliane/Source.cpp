/*Mugisha Liliane Abizera 
CIS 1111
8/3/2021
Final project Assignment
My program is the mortgage calculator and it is displaying the table in the mortgage file, 
It is showing average of the loan I paid and display the principal you choose to see.*/

#include<iostream>
#include<string>
#include<cmath>
#include<iomanip>
#include<fstream>
#include <chrono>


using namespace std;


void DisplayTable(int Month[], double mortgage[][4]) {
	
	cout << setw(5) << "MONTH" << "  " << setw(17) << "BEGINNING BALANCE" << "  " << setw(10) <<
		"INTEREST" << "  " << setw(11) << "PRINCIPAL" << "  " << setw(16) << "ENDING BALANCE" << endl;

for (int r = 0; r < 24; r++)
{
	cout << setw(11) << left << Month[r];
	for (int c = 0; c < 4; c++)
	{
		cout << setw(10) << right << mortgage[r][c] << "  ";
	}
	cout << endl;
	
}
}
double showAverage(int Month[], double mortgage[][4])
{
	double average= 0.00;
	for (int i = 0; i < 24; i++) {
		average += mortgage[i][0] + mortgage[i][1] + mortgage[i][2] + mortgage[i][3] / 4;
	}
		
	cout << setprecision(2) << fixed;
	cout <<"The average of the total loan is: "<<setw(2) << average << endl;
	return average;
}
void displayprincipal(int Month[], double mortgage[][4]) {
	int monthnum;
	cout << "Enter the month you want the number for the principal: " << endl;
	cin >> monthnum;
	for (int i = 0; i < 24; i++)
	{
		if (Month[i] == monthnum) {
			int position = i;
			cout << "For month " << monthnum << " principal is:  " << mortgage[position][2] << endl;
		}
	
	}

}


int main()
{
	
	int Month[24];
	double mortgage[24][4];
	int years, choice, monthnum;
	double principal,apr;
	double average;
	const int Table_choice = 1,
		      Average_choice = 2,
		      Principal_choice = 3,
		      end_choice = 4; 
	
	//Writing the file
	
	ofstream LoanFile;
	LoanFile.open("loan.txt");
		
			cout << "Enter the principal: ";
			cin >> principal;
			cout << "enter the APR(%) :";
			cin >> apr;
			cout << "Enter the loan terms(years): ";
			cin >> years;
			double R = (apr / 100) / 12;
			int N = years * 12;
			double payment = principal * R / (1 - pow(1 + R, -N));
			cout.setf(ios::fixed);
			cout.precision(2);
			cout << "Your montly payment is :" << payment << endl;
			LoanFile << "Your montly payment is :" << payment << endl;
			double balance = principal, totalInterest{}, total_principal{};

			cout << setw(5) << "MONTH" << "  " << setw(17) << "BEGINNING BALANCE" << "  " << setw(10) <<
				"INTEREST" << "  " << setw(11) << "PRINCIPAL" << "  " << setw(16) << "ENDING BALANCE" << endl;
			for (int i = 1; i <= N; i++) {
				double interest = balance * R;
				double principal = payment - interest;
				totalInterest += interest;
				total_principal+= principal;
				balance -= principal;
				cout << setw(5) << i << setw(20) << balance + principal << setw(11) << interest <<
					setw(12) << principal << setw(17) << balance << endl;
				LoanFile << setw(5) << i << setw(20) << balance + principal << setw(11) << interest <<
					setw(12) << principal << setw(17) << balance << endl;
		
			}
			cout<< "Total interest paid: " << totalInterest << endl;
			cout << "Total Amount Paid: " << total_principal + totalInterest << endl;

	LoanFile.close();

	// Reading the file
	ifstream monthFile;
	monthFile.open("Month.txt");
	for (int i = 0; i < 24; i++)
	{
		monthFile >> Month[i];
	}
	monthFile.close();
	
	ifstream inputloanFile;
	inputloanFile.open("mortgage.txt");
	for (int r = 0; r < 24; r++)
	{
		for (int c = 0; c < 4; c++)
		{
			inputloanFile >> mortgage[r][c];
		}
	}
	inputloanFile.close();
	
	do
	{
		// Display menu
		
		cout << "Enter 1 to display table "<<endl;
		cout << "Enter 2 to show Average " << endl;
		cout << "Enter 3 to display principal " << endl;
		cout << "Enter any other number to end the program " << endl;
		cout << "Enter selection ";
		cin >> choice;
		// validate the menu selection
		while (choice < Table_choice || choice > end_choice)
		{
			cout << " Please enter the valid menu selection ";
			cin >> choice;
		}

		//Get the menu choice
		switch (choice)
		{
		case 1: Table_choice:
		DisplayTable(Month, mortgage);
		break;
		case 2: Average_choice:
		 showAverage(Month, mortgage);
		break;
		case 3: Principal_choice:
			 displayprincipal(Month , mortgage);
			break;
		}	
	} while (choice!= end_choice);
	return 0;
}