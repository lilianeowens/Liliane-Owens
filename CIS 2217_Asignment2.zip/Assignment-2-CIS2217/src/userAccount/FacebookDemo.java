package userAccount;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class FacebookDemo {

	private static final Scanner IN = new Scanner(System.in);
	private static final PrintStream OUT = System.out;	
	private static final PrintStream ERR = System.err;

	private static ArrayList<FacebookUserClass> users;

	/**
	 * main method:
	 * 	1. creates users as new ArrayList of FacebookUsers
	 *  2. adds users by calling addUsers
	 *     if no uses added, ends program by throwing exception
	 *  3. outputs the users list
	 *  4. checks password of each user by calling checkPasswords
	 *  5. adds 1 friend for each user by calling addFriends
	 *  6. shows friends of users by calling showFriends
	 *  7. removes 1 friend per user by calling removeFriends
	 *  8. shows friends of users by calling showFriends
	 *  
	 * @param args String array of command line arguments (unused)
	 */
	public static void main(String[] args)
	{
		try
		{
			users = new ArrayList<FacebookUserClass>();


			// add users
			OUT.println("First, let's add some users");
			addUsers();
			Collections.sort(users);
			// if no users added, end program
			if (users.isEmpty())
			{
				throw new Exception("No users added; bye");
			}

			// output users
			OUT.println("\nusers list: " + users);

			// check passwords
			OUT.println("\nNow, we'll check passwords");
			checkPasswords();

			// need to flush Scanner before next input
			IN.nextLine();

			// add friends
			OUT.println("\nNext, let's add some friends");
			addFriends();

			// show friends
			OUT.println();
			showFriends();

			// remove friends
			OUT.println("\nOK, let's remove some friends");
			removeFriends();

			// show friends
			OUT.println();
			showFriends();
		}
		catch (Exception e)
		{
			ERR.println("Exception thrown: " + e);
		}


	} // end main method

	/**
	 * method continuously adds FacebookUser objects to
	 *   users ArrayList, until Enter is hit at name prompt
	 */
	private static final void addUsers()
	{
		boolean done = false;

		while (!done)
		{
			OUT.print("Enter the Facebook user's name (Enter to end): ");
			String name = IN.nextLine();

			if (name.isEmpty())
			{
				done = true;
				continue; // jump to top of loop
			}

			OUT.printf("Enter %s's password: ", name);
			String pwd = IN.next();

			OUT.printf("Enter a password hint for %s's password: ", name);
			String hint = IN.next();

			// add new FacebookUser to users
			FacebookUserClass newUser = new FacebookUserClass(name,pwd);
			newUser.setPasswordHint(hint);
			users.add(newUser );


			// need to flush Scanner before next input
			IN.nextLine();

		} // end while
	} // end addUsers method

	/**
	 * method checks the password of each FacebookUser
	 *   in the users ArrayList
	 */
	private static final void checkPasswords()
	{

		for (FacebookUserClass nextUser : users)
		{
			OUT.printf("%s: what is your password? Here's a hint: \n", nextUser.toString());
			nextUser.getPasswordHelp();
			String pwdInput = IN.next();
			if (nextUser.checkPassword(pwdInput))
			{
				OUT.println("Correct password");
			}
			else
			{
				OUT.println("Incorrect password");
			}
		} // end for each loop
	} // end checkPasswords method

	/**
	 * method adds 1 friend for each FacebookUser
	 *   in the users ArrayList
	 */
	private static final void addFriends()
	{

		for (FacebookUserClass nextUser : users)
		{
			OUT.printf("Add a friend for %s: ", nextUser);
			String name = IN.nextLine();

			FacebookUserClass nextFriend = findUser(name);

			if (nextFriend != null)
			{
				nextUser.friend(nextFriend);
			}
			else
			{
				ERR.printf("Sorry, %s is not a Facebook user\n", name);
			}

		} // end for each loop
	} // end addFriends method

	/**
	 * method removes 1 friend for each FacebookUser
	 *   in the users ArrayList
	 */
	private static final void removeFriends()
	{
		for (FacebookUserClass nextUser : users)
		{
			OUT.printf("Remove a friend for %s: ", nextUser);
			String name = IN.nextLine();

			FacebookUserClass nextFriend = findUser(name);

			if (nextFriend != null)
			{
				nextUser.deFriend(nextFriend);
			}
			else
			{
				ERR.printf(" %s is unknown friend\n", name);
			}
		} // end for each loop
	} // end removeFriends method

	/**
	 * method repeatedly shows friends of FacebookUsers
	 *   in the users ArrayList given a user's name
	 */
	private static final void showFriends()
	{

		boolean done = false;

		while (!done)
		{
			OUT.print("Enter the Facebook user's name (Enter to end): ");
			String name = IN.nextLine();
			if (name.isEmpty())
			{
				done = true;
				continue; // jump to top of loop
			}

			FacebookUserClass nextUser = findUser(name);

			if (nextUser == null)
			{
				ERR.printf("%s: not a Facebook user\n", name);
				continue;
			}

			OUT.printf("%s's friends: ", name);
			OUT.println(nextUser.getFriends());

		} // end while
	} // end showFriends method

	/**
	 * method returns the first FacebookUser with
	 *   the given name, or null if there is no such
	 *   FacebookUser
	 *   
	 * @param name the given name (String)
	 * @return the 1st FacebookUser with the name, or null
	 */
	private static final FacebookUserClass findUser(String name)
	{
		FacebookUserClass result = null;

		for (FacebookUserClass nextUser : users)
		{
			if (nextUser.isNamed(name))
			{
				result = nextUser;
				break; // end loop
			}
		} // end for each loop		

		return result;
	} // end findUser
	// end FacebookDemo class

}


