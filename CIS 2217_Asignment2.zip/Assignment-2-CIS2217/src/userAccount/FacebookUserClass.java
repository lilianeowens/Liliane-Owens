package userAccount;

import java.util.ArrayList;
import java.util.Collections;
/**
 * 
 * @author R-LO
 *FacebookUseClass is extending the userAccount1 class and implementing the comparable interface
 */
public class FacebookUserClass extends UserAccount1 implements Comparable<FacebookUserClass> {
	/**
	 * Fields
	 */
	private String passwordHint;

	private ArrayList<FacebookUserClass> friends = new ArrayList<>();

	/**
	 * constructors
	 * @param username
	 * @param password
	 */

	public FacebookUserClass(String username, String password) {
		super(username, password);

	}

	public FacebookUserClass(String username, String password, boolean active, String passwordHint) {
		super(username, password, active);
		this.passwordHint = passwordHint;

	}

	/**
	 * @return the passwordHint
	 */
	public String getPasswordHint() {
		return passwordHint;
	}

	/**
	 * @param passwordHint the passwordHint to set
	 */
	public void setPasswordHint(String hint) {
		this.passwordHint = hint;
	}

	/**
	 * @return the friends
	 */
	public ArrayList<FacebookUserClass> getFriends() {
		ArrayList<FacebookUserClass> friend = new ArrayList<FacebookUserClass>(friends);
		return friend;

	}

	/**
	 * @param friends the setter for friends 
	 */
	public void setFriends(ArrayList<FacebookUserClass> friends) {
		this.friends = friends;
	}
	public void friend(FacebookUserClass newFriend) {

		if ( (FacebookUserClass)newFriend != null) {
			friends.add(newFriend);
		}
		System.out.println(friends);	


	}
	public void deFriend(FacebookUserClass formerFriend) {

		friends.remove(formerFriend);
	}


	/**
	 *  Compares this object with the specified object for order. Returns a negative integer, zero, 
	 *  or a positive integer as this object is less than, equal to, or greater than the specified object. 
	 */
	@Override
	public int compareTo(FacebookUserClass otherName) {
		if (this.passwordHint.compareToIgnoreCase(otherName.passwordHint) != 0) {
			return this.passwordHint.compareToIgnoreCase(otherName.passwordHint);
		}

		if (super.getUsername().compareToIgnoreCase(otherName.getUsername()) != 0) {
			return super.getUsername().compareToIgnoreCase(otherName.getUsername());
		}

		if (this.passwordHint.compareTo(otherName.passwordHint) != 0) {
			return this.passwordHint.compareTo(otherName.passwordHint);
		}
		Collections.sort(friends);
		return 0;
	}
	/**
	 * create the password hint
	 * 
	 */
	@Override
	public void getPasswordHelp() {


		setPasswordHint(getPasswordHint());

	}
	//print the object
	@Override
	public String toString() {

		return String.format("%s",getUsername() );

	}


}









