#include "./io.h"
#include "./types.h"
int main() 

{
	// Clear the screen
	clearscreen();

	// Print "Hello World!"
	printf("Hello World!");
	
	return 0;
}