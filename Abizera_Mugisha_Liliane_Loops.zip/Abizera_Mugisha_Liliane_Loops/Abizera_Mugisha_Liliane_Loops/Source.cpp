/*Mugisha Liliane Abizera
CIS 1111
7/7/2021
Loops Assignment */
#include<iostream>
#include<string>
#include<cstdlib>
#include<cmath>
#include<iomanip>
using namespace std;

int main()
{
	float highest = 0.00, total = 0.0, average; 
	string months, highestMonth;
	int Eastsales, midSales, Westsales, expenses;
	char again;
	int netEastsales, netMidsales, netWestsales;
	

	do {
		cout << "Enter a month name:> ";
		cin >> months;
		cout << "Enter the sales for division East coast: \n";
		cin >> Eastsales;
		cout << "enter the expenses for division East coast: \n";
		cin >> expenses;
		cout << "Error. Expenses must be zero or greater: \n";
		cin >> expenses;
		netEastsales = Eastsales - (Eastsales * 0.3) - expenses;
	} while (expenses < 0);

	do {
		cout << "Enter the sales for division Mid west : \n";
		cin >> midSales;
			cout<<"\n ";
		cout << "enter the expenses for division Mid West: \n";
		cin >> expenses;
		netMidsales = midSales - (midSales * 0.3) - expenses;
	} while (expenses < 0);

	do {
		cout << "Enter the sales for division West coast :\n ";
		cin >> Westsales;
		cout << "enter the expenses for division West coast:\n ";
		cin >> expenses;
		netWestsales = Westsales - (Westsales * 0.3) - expenses;
	} while (expenses < 0);

	cout << "CPlusPlus & LandMinusMinus Net sales for " << months << endl;
	cout << "(each asterisk represents  $1000)\n\n";

		int eastStars = netEastsales / 1000, midStars = netMidsales / 1000, westStars = netWestsales / 1000;
		for (int i = 1; i < eastStars; i++) {
			cout << "*";	
		}
		cout << setprecision(2) << fixed;
			cout << "East Coast $  " << setw(5)<< netEastsales <<endl;

		for (int i = 1; i < midStars; i++) {
			cout << "*";
		}
		cout << setprecision(2) << fixed;
		cout << "Mid west   $  " << setw(4) << netMidsales << endl;


		for (int i = 1; i < westStars; i++) {
			cout << "*";
		}
            cout << setprecision(2) << showpoint <<fixed;
			cout << "West Coast $  " << setw(4)<<netWestsales << endl;

		float total_net = netEastsales + netMidsales + netWestsales;

		do {
			cout << "Enter a month name:> ";
			cin >> months;
			cout << "Enter the sales for division East coast: \n";
			cin >> Eastsales;
			cout << "enter the expenses for division East coast: \n";
			cin >> expenses;
			netEastsales = Eastsales - (Eastsales * 0.3) - expenses;
		} while (expenses < 0);

		do {
			cout << "Enter the sales for division Mid west : \n";
			cin >> midSales;
			cout << "enter the expenses for division Mid West: \n";
			cin >> expenses;
			netMidsales = midSales - (midSales * 0.3) - expenses;
		} while (expenses < 0);

		do {
			cout << "Enter the sales for division West coast :\n ";
			cin >> Westsales;
			cout << "enter the expenses for division West coast:\n ";
			cin >> expenses;
			netWestsales = Westsales - (Westsales * 0.3) - expenses;
		} while (expenses < 0);
		
		
		cout << "CPlusPlus & LandMinusMinus Net sales for "<< months<< endl;
		cout << "(each asterisk represents  $1000)\n\n";
		
		int eastStars2 = netEastsales / 1000, midStars2 = netMidsales / 1000, westStars2 = netWestsales / 1000;

		for (int i = 1; i < eastStars2; i++) {
			cout << "*";
		}
		cout << setprecision(2) << fixed;
			cout << "East Coast $  " << setw(4) << netEastsales <<endl;


		for (int i = 1; i < midStars2; i++) {
			cout << "*";
		}
		    cout << setprecision(2) << fixed;
			cout << "Mid west   $  " << setw(4) << netMidsales << endl;
		

		for (int i = 1; i < westStars2; i++) {
			cout << "*";
		}
		    cout << setprecision(2) << fixed;
			cout << "West Coast $  " << setw(5) << netWestsales << endl;
		
		
		do {
			cout << "Enter Y for another month or enter something else.\n";
			cin >> again;
		} while (again == 'n' || again == 'N');
			float totalnet = netEastsales + netMidsales + netWestsales;
			average = (total_net + totalnet) / 2.0;
		
		cout << "The average of net sales for a month are $ " << average << endl;
		
		if (total_net > highest)
		{
			highest = total_net;
			highestMonth = months;
			cout << highestMonth << " had the highest net Sales of  $ " << total_net << endl;
		}
		
		return (0);
	}
