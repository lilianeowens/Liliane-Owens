//CEG 4750/6750      Information Security
//Robert Green and Liliane Owens
//(Undergraduate)
//Professor: Meilin Liu
//4/16/2024
//Programming Project 3
//Spring 2024

//Code based off of:
//	aes_encode.cpp file from project II (CEG 4750 @ WSU, Pro. Melin Liu, Spring 2024)
//	Sample code found at: cryptopp.com/wiki/HMAC (Accessed 4/16/2024)

#include <cryptopp/hmac.h>
#include "cryptopp/osrng.h"
#include<iostream>
#include<fstream>
#include<sstream>
#include<string>
#include<cstring>
#include<iomanip>
#include"cryptopp/cryptlib.h"
#include"cryptopp/hex.h"
#include"cryptopp/filters.h"
#include"cryptopp/hmac.h"
#include"cryptopp/sha.h"

using namespace std;
using namespace CryptoPP;

int main(int argc, char * argv[]){
	if(argc != 4){
		cout<<"usage: hmac infile outfile key(16bytes)"<<endl;
		return 0;
	}
	
	//open [and read] in/out files
	fstream file1;
	fstream file2;
	file1.open(argv[1], ios::in);
	file2.open(argv[2], ios::out);
	stringstream buffer;
	buffer << file1.rdbuf();
	string plain(buffer.str());

	// set up key
	byte bKey[HMAC< SHA512 >::DEFAULT_KEYLENGTH];
	memset(bKey,0,HMAC< SHA512 >::DEFAULT_KEYLENGTH);
	for(int i=0;i<HMAC< SHA512 >::DEFAULT_KEYLENGTH;i++){
		if(argv[3][i]!='\0') bKey[i] =(byte)argv[3][i];
		else break;
	}
	SecByteBlock key(bKey, HMAC< SHA512 >::DEFAULT_KEYLENGTH);

	
	string mac, encoded;
	encoded.clear();
	StringSource ss1(key, key.size(), true,
			new HexEncoder(
				new StringSink(encoded)
				)
			);
	cout << "key: " << encoded << endl;
	cout << "plain text: " << plain << endl;
	//do encryption
	try{
		HMAC< SHA512 > hmac(key,key.size());
		StringSource ss2(plain, true,
				new HashFilter(hmac,
					new StringSink(mac)
					)
				);
	}
	catch(const CryptoPP::Exception& e){
		cerr << e.what() << endl;
		exit(1);
	}
	encoded.clear();
	//output pretty
	StringSource ss3(mac, true,
			new HexEncoder(
				new StringSink(encoded)
				)
			);
	cout <<"hmac: " << encoded << endl;
	//output to file
	file2 << encoded;
	cout <<"Output stored in: "<<argv[2]<<endl;
	return 0;
}
