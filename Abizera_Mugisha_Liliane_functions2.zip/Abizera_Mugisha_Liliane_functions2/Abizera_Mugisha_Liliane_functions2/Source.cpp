/* Mugisha Liliane Abizera
CIS 1111
More Functions Assignement
07/19/2021*/

#include<iostream>
#include<string>
#include<iomanip>

using namespace std;
float calculateBattingAverage(string & PlayerName);


float calculateBattingAverage(string & PlayerName)
{
		
	int hits{}, atBats{};
	int gameCounter = 1;
	char game;
	float total = 0.000, total_atBats = 0.000; // Accumulators

	do
	{
		cout << "\n enter the hits for player " << PlayerName << " for game # " << gameCounter << endl;
		cin >> hits;
		cout << "Enter the at-bats  " << PlayerName << " for game # " << gameCounter << endl;
		cin >> atBats;
		gameCounter++;// counter
		
		
		//validate hits>=0,atBats>=0
		while (hits < 0 || atBats < 0)
		{
			cout << "Error. Try again.";
			cin >> hits, atBats;
		}
		//validate hits dont exceed atBats

		while (hits > atBats)
		{
			cout << "Enter the hits that dont exceed at-bats ";
			cin >> hits;
		}
		
		total += hits;
		total_atBats += atBats;
		cout << "enter y for more games for " << PlayerName << " else enter n to quit >";
		cin >> game;
		cout << " \n";
	} while (game == 'y' || game == 'Y');
	
	
	//return batting average
	
	
	float average = total / total_atBats;
		return average;
	
}
string showProficiency( float & average)
{
	string proficiency;

	cout << "In the showProficiency function " << endl;


	if (average >= 0.000 && average < 0.250) {
		proficiency = "Minor Leaguer";
		return proficiency;
	}
	else if (average >= 0.250 && average < 0.300) {
		proficiency = "All Star";
		return proficiency;
	}
	else if (average >= 0.300 && average < 0.400) {
		proficiency = "Hall of Famer ";
		return proficiency;
	}
	else {
		proficiency = "King of Baseball ";
	}
	return proficiency;
}

	
int main() 
{
	char again;
	string PlayerN, proficiency;
	int gameCounter = 1, hits,atBats;
	float battingAverage;

	do
	{
		cout << " enter the Player's name ";
		getline(cin, PlayerN);

//call the calculate batting Average and show proficiency
	battingAverage = calculateBattingAverage(PlayerN);
	proficiency = showProficiency(battingAverage);
		
	cout << fixed << showpoint << setprecision(3);
	cout << "Player " << PlayerN << "'s batting average is " << battingAverage << " and so far his proficiency is: " << proficiency << "!!!!" << endl;

		cout << "Enter Y for another Player's name or enter n to quit\n ";
		cin>> again;
		getline(cin, PlayerN);
		
		
	} while (again =='Y' || again =='y');

	return 0;
}
