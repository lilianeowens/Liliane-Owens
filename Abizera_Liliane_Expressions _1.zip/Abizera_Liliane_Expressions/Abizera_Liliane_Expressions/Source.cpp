// Mugisha Liliane Abizera
// 6/12/2021
// CIS 1111
// Expression 

#include<iostream>
#include<string>
#include<iomanip>
#include<cmath>
using namespace std;

int main()
{
	int numGuests;
	float lengthMin;
	string nameOfEvent, customerFullName;
	
	cout << "Enter the name of the event: " << endl;
	getline(cin, nameOfEvent);
	cout << "Enter the customer first and last name:" << endl;
	getline(cin, customerFullName);
	cout << "Enter the number of guests to serve: ";
	cin >> numGuests;
	cout << "what is the lenght of time in minutes ?: ";
	cin >> lengthMin; 
	cout << nameOfEvent << endl;
	cout << "Event estimate for  "<< customerFullName << endl;

	float serversTemp = numGuests / 15.0;
	int nuServers = ceil(serversTemp);
	cout << "Number of servers :" << nuServers << endl << endl << endl;
	
	const double lengthHour = 125 % 60;
	const double COST_PER_HOUR = 15.0 *2;
	const double COST_PER_MINUTES = 0.50 * 5;
	double costPerServer = COST_PER_HOUR + COST_PER_MINUTES ;
	double totalCostServers = costPerServer * 2;
	float COST_PER_DINNER = 31.80;
	float totalCostDinner = COST_PER_DINNER * numGuests;
	float totalCost = totalCostServers + totalCostDinner;
	double avg_person = totalCost / numGuests;
	float deposit = totalCost * 0.25;
	
	cout <<setprecision(2)<< fixed;
	cout << "How many servers are serving ?           " << setw(7) << nuServers << endl;
	cout << "How much both the servers will get paid? " << setw(10)<< totalCostServers << endl;
	cout << "what is the total cost of food:          " << setw(10)<< totalCostDinner << endl;
	cout << "what is the average cost per person:       "<<setw(8)<< avg_person << endl;
	cout << "what is the total cost :                   " <<setw(8) << totalCost << endl << endl;
	cout << "Please provide a 25% deposit to reserve the event" << endl;
	cout << "The deposit is :                        "<< setw(11) << deposit << endl << endl << endl;
	
	
	system("pause");
	return 0;
}