package calculjavafx;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class Calculator extends Application {

	@Override
	public void start(Stage primaryStage) {
		GridPane pane = new GridPane();
		pane.setPadding(new Insets(5, 5, 5, 5));
		pane.setAlignment(Pos.CENTER);
		
		TextField answer = new TextField();
		answer.setText("0.0");
		answer.setEditable(false);
		answer.setMaxWidth(200);
		answer.setPadding(new Insets(10, 10, 10, 10));
		answer.setStyle("-fx-font-family: Courier;"
					  + "-fx-font-size: 20;"
					  + "-fx-font-weight: bold;");
		pane.add(answer, 0, 0, 4, 1);
		
		Button seven = new Button("7");
		seven.setMinWidth(50);
		seven.setMinHeight(50);
		seven.setStyle("-fx-font-family: Courier;"
				  	 + "-fx-font-size: 20;");
		pane.add(seven, 0, 1);
		
		Button eight = new Button("8");
		eight.setMinWidth(50);
		eight.setMinHeight(50);
		eight.setStyle("-fx-font-family: Courier;"
				  	 + "-fx-font-size: 20;");
		pane.add(eight, 1, 1);
		
		Button nine = new Button("9");
		nine.setMinWidth(50);
		nine.setMinHeight(50);
		nine.setStyle("-fx-font-family: Courier;"
				  	+ "-fx-font-size: 20;");
		pane.add(nine, 2, 1);
		
		Button divide = new Button("/");
		divide.setMinWidth(50);
		divide.setMinHeight(50);
		divide.setStyle("-fx-font-family: Courier;"
				  	  + "-fx-font-size: 20;");
		pane.add(divide, 3, 1);
		
		Button four = new Button("4");
		four.setMinWidth(50);
		four.setMinHeight(50);
		four.setStyle("-fx-font-family: Courier;"
				  	+ "-fx-font-size: 20;");
		pane.add(four, 0, 2);
		
		Button five = new Button("5");
		five.setMinWidth(50);
		five.setMinHeight(50);
		five.setStyle("-fx-font-family: Courier;"
				  	+ "-fx-font-size: 20;");
		pane.add(five, 1, 2);
		
		Button six = new Button("6");
		six.setMinWidth(50);
		six.setMinHeight(50);
		six.setStyle("-fx-font-family: Courier;"
				  + "-fx-font-size: 20;");
		pane.add(six, 2, 2);
		
		Button multiply = new Button("*");
		multiply.setMinWidth(50);
		multiply.setMinHeight(50);
		multiply.setStyle("-fx-font-family: Courier;"
				  	    + "-fx-font-size: 20;");
		pane.add(multiply, 3, 2);
		
		Button one = new Button("1");
		one.setMinWidth(50);
		one.setMinHeight(50);
		one.setStyle("-fx-font-family: Courier;"
				   + "-fx-font-size: 20;");
		pane.add(one, 0, 3);
		
		Button two = new Button("2");
		two.setMinWidth(50);
		two.setMinHeight(50);
		two.setStyle("-fx-font-family: Courier;"
				  + "-fx-font-size: 20;");
		pane.add(two, 1, 3);
		
		Button three = new Button("3");
		three.setMinWidth(50);
		three.setMinHeight(50);
		three.setStyle("-fx-font-family: Courier;"
				  	 + "-fx-font-size: 20;");
		pane.add(three, 2, 3);
		
		Button minus = new Button("-");
		minus.setMinWidth(50);
		minus.setMinHeight(50);
		minus.setStyle("-fx-font-family: Courier;"
				  	 + "-fx-font-size: 20;");
		pane.add(minus, 3, 3);
		
		Button clear = new Button("C");
		clear.setMinWidth(50);
		clear.setMinHeight(50);
		clear.setStyle("-fx-font-family: Courier;"
				  	 + "-fx-font-size: 20;");
		pane.add(clear, 0, 4);
		
		Button zero = new Button("0");
		zero.setMinWidth(50);
		zero.setMinHeight(50);
		zero.setStyle("-fx-font-family: Courier;"
				  	+ "-fx-font-size: 20;");
		pane.add(zero, 1, 4);
		
		Button decimal = new Button(".");
		decimal.setMinWidth(50);
		decimal.setMinHeight(50);
		decimal.setStyle("-fx-font-family: Courier;"
				  	   + "-fx-font-size: 20;");
		pane.add(decimal, 2, 4);
		
		Button plus = new Button("+");
		plus.setMinWidth(50);
		plus.setMinHeight(50);
		plus.setStyle("-fx-font-family: Courier;"
				  	+ "-fx-font-size: 20;");
		pane.add(plus, 3, 4);
		
		Button equals = new Button("=");
		equals.setMinWidth(200);
		equals.setMinHeight(50);
		equals.setStyle("-fx-font-family: Courier;"
				  	  + "-fx-font-size: 20;");
		pane.add(equals, 0, 5, 4, 1);
		
		Scene scene = new Scene(pane);
		primaryStage.setTitle("Calculator");
		primaryStage.setScene(scene);
		primaryStage.setResizable(false);
		primaryStage.show();
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}