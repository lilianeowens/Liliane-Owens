#pragma once
/** @file Game1.h */
/** Liliane Owens
	CIS 2207 NO1
	9/7/22
Design and implement an ADT for a one-person guessing game that chooses n random integers
in the range of 1 to m and asks the user to guess them.  The same integer might be chosen
more than once.  For example, the game might choose the following four integers that
range from 1 to 10: 4, 6, 1, 6.*/

#ifndef GAME_1_
 #define GAME_1_
#include <cstdlib>	
 
// Declaration for the class GAME1
 class Game1
{
 private:
   // Data field
	 int* randomVector;
	 int* foundVector;
	
  // Parameterized constructor
	 
 public:
	 Game1() {
	randomVector = NULL;
	foundVector = NULL;
	 }
	 // Method to get the guesses
	 void startGuess(int m, int n);

	 // Method to create the random number 
	 void createRandomNum(int m, int n);
	
 };// end Game1.h

#endif
