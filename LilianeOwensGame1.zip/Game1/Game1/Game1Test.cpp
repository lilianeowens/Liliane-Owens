/** @file Game1Test.cpp */
/** Liliane Owens
	CIS 2207 NO1
	9/7/22
Design and implement an ADT for a one-person guessing game that chooses n random integers
in the range of 1 to m and asks the user to guess them.  The same integer might be chosen
more than once.  For example, the game might choose the following four integers that
range from 1 to 10: 4, 6, 1, 6.*/

#include <iostream>
#include "Game1.h"

using namespace std;

int main() {

	Game1 guess;

	while (true) {

		int n, m;
		cout << "Enter range value from 1 to (m): ";
		cin >> m;
		cout << "How many number you want to guess ? ";
		cin >> n;

		guess.startGuess(m, n);

		cout << "Play again (Y/N)? ";
		char ch;
		cin >> ch;

		if (ch == 'n' || ch == 'N')
			break;
	}

	cout << "Good Bye" << endl;

	return 0;
}//end Game1Test