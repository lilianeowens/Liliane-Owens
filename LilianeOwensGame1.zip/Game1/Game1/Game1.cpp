/** @file Game1.cpp */
/** Liliane Owens
    CIS 2207 NO1
    9/7/22 
Design and implement an ADT for a one-person guessing game that chooses n random integers
in the range of 1 to m and asks the user to guess them.  The same integer might be chosen 
more than once.  For example, the game might choose the following four integers that 
range from 1 to 10: 4, 6, 1, 6.*/

#include <cstdlib>
#include <iostream>
#include <ctime>
#include "Game1.h"

using namespace std;

void Game1::startGuess(int m, int n) {

	createRandomNum(m, n);
	srand(time(0));

	int* temp = new int[n];
	while (true) {
		cout << "Enter your guesses for the " << n << " integers in the range from 1 to " << m << " that have been selected:" << endl;
		for (int i = 0; i < n; i++) {
			cin >> temp[i];
		}
		//Loop for searching the guesses
		for (int i = 0; i < n; i++)
			foundVector[i] = 0;

		int count = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (foundVector[j] == 0 && randomVector[i] == temp[j]) {
					//cout<<"Found: "<<temp[j]<<endl;
					foundVector[j] = 1;
					count++;
					break;
				}
			}
		}

		if (count == n) {
			cout << "You are correct!";
			delete[] randomVector;
			delete[] foundVector;
			delete[] temp;
			return;
		}
		else {
			cout << count << " of your guesses are correct. Guess again." << endl;
		}
	}
}

void Game1::createRandomNum(int m, int n) {

	// creating memory
	randomVector = new int[m];
	foundVector = new int[m];

	for (int i = 0; i < n; i++)
		foundVector[i] = 0;

	cout << "Game random number: ";
	for (int i = 0; i < n; i++) {
		randomVector[i] = rand() % m + 1;
		cout << randomVector[i] << " ";
	}// end the for loop
	cout << endl;
}// end Game1.Cpp