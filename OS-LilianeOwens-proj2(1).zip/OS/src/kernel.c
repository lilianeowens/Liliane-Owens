#include "./io.h"
#include "./types.h"

int main()
{
	initkeymap();
	// Clear the screen
	clearscreen();
	char input[100]; // Max input size: 100 characters + null terminator

	// Print "Hello World!"
	printf("Hello World!\n");
	while (1)
	{
		printf("\nPlease enter a string: ");
		scanf(input);
		printf("\nYou typed: ");
		printf(input);
		printf("\n");
	}
	return 0;
}
