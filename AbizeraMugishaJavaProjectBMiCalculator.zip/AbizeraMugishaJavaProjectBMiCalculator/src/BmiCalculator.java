import java.util.Scanner;

public class BmiCalculator {

	public static void main(String[] args) {


	Scanner input = new Scanner(System.in);
		
	double weight = 0.0;
	double height = 0.0;
	System.out.print("Enter your Weight in pounds: ");
	weight = input.nextDouble();
	System.out.println("weight ==" + weight);
	System.out.print("Enter your heights in inches: ");
	height = input.nextDouble();
	System.out.println("height ==" + height);
	
	double BMI = findBMI(weight, height);
	System.out.println("Your BMI == " + BMI);
	double BodyMassIndex = 0.0;
	System.out.print("A BMI between 20 and 24 is considered ideal. What would you like your BMI be ");
	BodyMassIndex = input.nextDouble();
	System.out.println(BodyMassIndex);
	
	double weightOne = BodyMassIndex * (height * height)/703;
	System.out.print("Your weight needs to be " + weightOne );
	System.out.println(" pounds for your BMI to be " + BodyMassIndex);

	}
	

	public static double findBMI(double weight,double height) {
		double result = (weight/ (height * height)) * 703;
		return result;
	}
	
}
