// Mugisha Liliane Abizera
//6/3/2021
//CIS 1111
// Basic Math

#include<iostream>
#include<string>
using namespace std;

int main()
{
	int tablets = 5;
	int desktops = 5;
	string nameOfCompany;
	float tabletCost = 320.00;
	float desktopCost = 800.00;
	float totalTabletCost = tablets * tabletCost;
	float totalDesktopCost = desktops * desktopCost;
	float totalComputerCost = totalTabletCost + totalDesktopCost;
	float numberOfComputersPurchased = tablets + desktops;
	cout << totalTabletCost << endl;
	cout << totalDesktopCost << endl;
	cout << totalComputerCost << endl;
	// if paying cash for the purchase

	float cashDiscount = totalComputerCost * 0.10;
	float subtotal = totalComputerCost - cashDiscount;
	float cashTax = subtotal * 0.075;
	float totalBill = subtotal + cashTax;
	float averageCost = totalBill / numberOfComputersPurchased;
	
	cout << "enter the name of the company " << endl;
	cin >> nameOfCompany;
	cout << "Enter the number of tablets to purchase " << tablets << endl;
	cout << "Enter the number of desktop computers to purchase " << desktops << endl;
	cout << "Invoice for sinclair Industries " << endl << endl;
	cout << "cost for 5 Tablets $" << totalTabletCost << endl;
	cout << "cost for 5 Desktops is $" << totalDesktopCost << endl << endl;
	
	cout << "If paying cash for the purchase " << endl;
	cout << "The subtotal is $" << subtotal << endl;
	cout << "Tax is $" << cashTax << endl;
	cout << "the total bill is $" << totalBill << endl;
	cout << "the average cost per computer is  $" << averageCost << endl << endl;

	// if financing the purchase 

	float financeCharge = totalComputerCost * 0.15;
	float subtotalCost = totalComputerCost + financeCharge;
	float financingTax = subtotalCost * 0.075;
	float totalBillCost = subtotalCost  + financingTax;
	float averagePrice = totalBillCost / numberOfComputersPurchased;
	
	cout << "If financing the purchase " << endl;
	cout << "the subtotal is $" << subtotalCost << endl;
	cout << "Tax is $ " << financingTax << endl;
	cout << "The total bill is $" << totalBillCost << endl;
	cout << "The average computer is $" << averagePrice << endl;
	cout << "By paying cash you would save $150.50 per computer " << endl << endl;

	return 0;
}