#include "./types.h"

struct idt_entry			// IDT structure
{
	unsigned short base_lo;
	unsigned short sel;	
	unsigned char always0;	
	unsigned char flags;	
	unsigned short base_hi;
} __attribute__((packed));

struct idt_ptr				// IDT poiner
{
	unsigned short limit;
	unsigned int base;
} __attribute__((packed));



struct idt_entry idt[256];
struct idt_ptr _idtp;


extern  void _idt_load();		// ---> interrupt.asm
void* memset(void* dest, unsigned char val, uint32 count);


void idt_set_gate(unsigned char num, unsigned long base, unsigned short sel, unsigned char flags)
{
	
	idt[num].base_lo = (base & 0xFFFF);
	idt[num].base_hi = (base >> 16) & 0xFFFF;

	
	idt[num].sel = sel;
	idt[num].always0 = 0;
	idt[num].flags = flags;
}


void idt_install()
{
	
	_idtp.limit = (sizeof (struct idt_entry) * 256) - 1;
	_idtp.base = (unsigned int)&idt;

	/* Clear out the entire IDT, initalizing it to zeros */
	memset(&idt, 0, sizeof(struct idt_entry) * 256);

	/* Add any new ISRs to the IDT here using idt_set_gate */

	/* Points the processor's internal register to the new IDT */
	_idt_load();
}

void* memset(void* dest, unsigned char val, uint32 count){ 
    /* Indicate failure */
    if (!dest)
	{
		return 0;
	}

	unsigned char* destC = (unsigned char*)dest;
	uint32 i;
	for (i = 0; i < count; i++)
		destC[i] = val;
	return dest;
}