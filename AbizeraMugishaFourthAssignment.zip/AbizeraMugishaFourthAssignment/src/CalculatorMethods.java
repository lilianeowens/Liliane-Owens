import java.util.Scanner;

public class CalculatorMethods {

	public static void main(String[] args) {


		int choice= 0;

		System.out.println(" What would you like to do? (the input ends if it is 6):");
		getMenuOption(choice);
	}

	public static int getMenuOption(int choice) {
		int menu = 0,
		    operand1 = 0,
			operand2 = 0;	
		Scanner input = new Scanner(System.in);	
		do 
		{

			System.out.print(
					" Menu\n" + 
							" 1. Add\n" + 
							" 2. Substract\n" +
							" 3. Multiply\n" + 
							" 4. Didide\n " + 
							" 5. Generate random number \n" +
							" 6. Quit\n\n");


			menu =input.nextInt();

			switch (menu)
			{ 

			case 1:// Add

				add(operand1, operand2);
				break;


			case 2: // Subtract 
				subtract(operand1, operand2);
				break;

			case 3:// Multiply 

				multiply(operand1, operand2);
				break;

			case 4: // Divide 

				divide(operand1, operand2);
				break;

			case 5: // Generate random number

				double lowerLimit = 0, upperLimit = 0;
				random(lowerLimit, upperLimit);
				break;

			case 6:// Quit 
				System.out.println("Goodbye!"); 
				break;

			default :

				System.out.println("I am sorry, " + menu + " was not one of the options.");

			}

		}while(menu != 6);
		input.close();
		return menu;
	}

	public static double getOperand(String prompt) {
		Scanner in = new Scanner(System.in);
		System.out.print(prompt);

		double result = in.nextDouble();

		return result;
	}

	public static double add(double operand1, double operand2) {

		operand1 = getOperand("What is the first number?: ");
		operand2 = getOperand("What is the second number?: ");
		double result = (operand1 + operand2);
		System.out.println("Answer: " + result); 
		return result;


	}

	public static double subtract(double operand1, double operand2) {
		operand1 = getOperand("What is the first number?: ");
		operand2 = getOperand("What is the second number?: ");
		double result = (operand1 - operand2);
		System.out.println("Answer: " + result);
		return result;

	}

	public static double multiply(double operand1, double operand2) {
		operand1 = getOperand("What is the first number?: ");
		operand2 = getOperand("What is the second number?: ");
		double result = (operand1 * operand2);
		System.out.println("Answer: " + result);
		return result;

	}

	public static double divide(double operand1, double operand2) {

		operand1 = getOperand("What is the first number?: ");
		operand2 = getOperand("What is the second number?: ");
		double result = (operand1 / operand2);
		if (operand2 == 0) {
		System.out.println("I'm sorry you can't divide by zero.\n" + "Answer: NaN ");

		} 
		System.out.println("Answer: " + result);
		return result;

	}

	public static double random(double lowerLimit, double upperLimit) {
		lowerLimit = getOperand("What is the lower limit: ");
		upperLimit = getOperand("What is the upper limit: ");
		double result = lowerLimit + Math.random() *(upperLimit - lowerLimit); 
		System.out.println("Answer : " + result); 
		return result;
	}

}
