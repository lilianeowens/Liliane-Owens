import java.io.File;
import java.io.FileNotFoundException;
import java.util.Objects;
import java.util.Scanner;
import javax.swing.JFileChooser;


public class MemoryCalcul {

	private double currentValue;	
	private double previousValue;
	private double op;
	
	private boolean clearStatus = false;
	
	private String mathSymbol = null;
	
	public double getCurrentValue() {
		return currentValue;
	}

	public void setCurrentValue(double currentValue) {
		this.currentValue = currentValue;
	}
	
	public double getPreviousValue() {
		return previousValue;
	}
	
	public void setPreviousValue(double previousValue) {
		this.previousValue = previousValue;
	}
	
	public double getOp() {
		return op;
	}
	
	public void setOp(double op) {
		this.op = op;
	}
	
	public boolean getClearStatus() {
		return clearStatus;
	}
	
	public void setClearStatus(boolean clearStatus) {
		this.clearStatus = clearStatus;
	}
	
	public String getMathSymbol() {
		return mathSymbol;
	}
	
	public void setMathSymbol(String mathSymbol) {
		this.mathSymbol = mathSymbol;
	}

	public int displayMenu() {
		Scanner input = new Scanner(System.in);

		int menu = -1;

		while (menu < 1 || menu > 7) {
			System.out.println();
			System.out.println("Menu");
			System.out.println("1. Add");
			System.out.println("2. Subtract");
			System.out.println("3. Multiply");
			System.out.println("4. Divide");
			System.out.println("5. Clear");
			System.out.println("6. Save");
			System.out.println("7. Quit");
			System.out.println();
			System.out.print("What would you like to do? ");

			menu = input.nextInt();

			if (menu < 1 || menu > 7) {
				System.out.println(menu + " wasn't one of the options");
			}

			if (menu == 7) {
				System.out.println("Goodbye!");
				System.exit(0);
			}
		}

		return menu;
	}

	public double getOperand(String prompt) {
		Scanner input = new Scanner(System.in);
		System.out.print(prompt);
		return input.nextDouble();
	}

	public void add(double operand2) {
		clearStatus = false;
		mathSymbol = "+";
		op = operand2;
		previousValue = currentValue;
		currentValue += operand2;
	}
	
	public void subtract(double operand2) {
		clearStatus = false;
		mathSymbol = "-";
		op = operand2;
		previousValue = currentValue;
		currentValue -= operand2;
	}
	
	public void multiply(double operand2) {
		clearStatus = false;
		mathSymbol = "*";
		op = operand2;
		previousValue = currentValue;
		currentValue *= operand2;
	}
	
	public void divide(double operand2) {
		clearStatus = false;
		mathSymbol = "/";
		op = operand2;
		previousValue = currentValue;
		if (operand2 == 0) {
			currentValue /= Double.NaN;
		}
		else
			currentValue /= operand2;
	}

	public void clear() {
		clearStatus = true;
		currentValue = 0;
		previousValue = 0;
		op = 0;
	}

	public void save(java.util.ArrayList<String> sList) throws FileNotFoundException {
		
		File file = null;	
				// use the JFilechooser class to allow the user to select a file 
				JFileChooser chooser = new JFileChooser();
				
				// This makes it so the user can pick a File
				 chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
				 
				// APPROVE_OPTION means the user clicked OK rather than 
					// cancel or just closing the dialog
		int returnVal = chooser.showOpenDialog(null);
		
		if(returnVal == JFileChooser.APPROVE_OPTION) {
			file = chooser.getSelectedFile();
			
			try(java.io.PrintWriter output = new java.io.PrintWriter(file)) {
				for(String i : sList) {
					output.printf("%s%n", i);
				}
			}
		}
	}
		
	@Override
	public int hashCode() {
		return Objects.hash(currentValue);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MemoryCalcul other = (MemoryCalcul) obj;
		return Double.doubleToLongBits(currentValue) == Double.doubleToLongBits(other.currentValue);
	}

	@Override
	public String toString() {
		if(mathSymbol == null) {
			return String.format("Initial value is 0");
		}
		else if(clearStatus == true) {
			return String.format("Cleared");
		}
		else {
			return String.format("%,.1f %s %,.1f = %,.1f", previousValue, mathSymbol, op, currentValue);
		}
	}
}






