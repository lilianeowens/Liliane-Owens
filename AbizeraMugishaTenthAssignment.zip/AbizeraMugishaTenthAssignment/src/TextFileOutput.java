import java.io.PrintWriter;
import java.io.Writer;
import java.util.Scanner;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import javax.swing.JOptionPane;


public class TextFileOutput extends MemoryCalcul {


	public static void main(String[] args) throws FileNotFoundException {
		JOptionPane.showMessageDialog(null, "choose a file");
		File filename = null;
		ArrayList<String> sList = new ArrayList<String>();
		String text = " ";


		if (!text.isEmpty()) {
			sList.add(text);
		}
		PrintWriter output = null;

		try {
			filename= new File("text.txt");
			output= new PrintWriter(filename);

			Writer output1 = new BufferedWriter(output);
			int size = sList.size();
			for(int i = 0; i< size; i++) {

				output.write(sList.get(i).toString());
			}

		}catch(FileNotFoundException e) {
			System.out.println(e.getMessage());
		}

		finally {
			if(output != null) {
				output.close();
			}
		}

		Scanner inKeyboard = new Scanner(System.in);	
		String message = "what is the second number ?";
		double op2;

		MemoryCalcul calc = new MemoryCalcul();

		sList.add(calc.toString());

		System.out.println("The current value is  " + calc.getCurrentValue() );
		int choice;

		do {
			choice = calc.displayMenu(); // Invoke the display menu from MemCalcul class

			switch (choice) { 

			case 1:// Add

				op2 = calc.getOperand(message);

				calc.add(op2);
				sList.add(calc.toString());

				System.out.println("The current value is " + calc.getCurrentValue());
				break;

			case 2: // Subtract 

				op2 = calc.getOperand(message);

				calc.subtract(op2);
				sList.add(calc.toString());

				System.out.println("The current value is " + calc.getCurrentValue());

				break;

			case 3:// Multiply 
				op2 = calc.getOperand(message);

				calc.multiply(op2);
				sList.add(calc.toString());

				System.out.println("The current value is " + calc.getCurrentValue());
				break;

			case 4: // Divide 
				op2 = calc.getOperand(message);

				calc.divide(op2);
				sList.add(calc.toString());

				System.out.println("The current value is " + calc.getCurrentValue());

				break;

			case 5:  // Clear

				calc.clear();
				sList.add(calc.toString());

				System.out.println("The current value is " + calc.getCurrentValue());
                
				break;


			case 6: //Save


				calc.save(sList);

				System.out.println("The current value is " + calc.getCurrentValue()); 

				break;


			case 7:// Quit 
				System.out.println("Goodbye!"); 
				break;

			default:
				System.out.println("I am sorry, " + choice + " was not one of the options.\n");
			}

		}while(choice != 7);

		inKeyboard.close();	


	}


}






