#include "./io.h"
#include "./multitasking.h"
#include "./irq.h"
#include "./isr.h"
//#include "./fat.h"

void prockernel();
void proc_a();
void proc_b();
void proc_c();
void proc_d();
void proc_e();

int main()
{
	// Clear the screen
	clearscreen();

	// Initialize our keyboard
	initkeymap();

	// Initialize interrupts
	idt_install();
	isrs_install();
	irq_install();

	// Start executing the kernel process
	startkernel(prockernel);

	return 0;
}

void prockernel()
{
	// Create the user processes
	createproc(proc_a, (void *)0x10000);
	createproc(proc_b, (void *)0x11000);
	createproc(proc_c, (void *)0x12000);
	createproc(proc_d, (void *)0x13000);
	createproc(proc_e, (void *)0x14000);
	// Count how many processes are ready to run
	int userprocs = ready_process_count();

	printf("Kernel Process Starting...\n");

	// As long as there is 1 user process that is ready, yield to it so it can run
	while (userprocs > 0)
	{
		// Yield to the user process
		yield();

		//printf("Kernel Process Resumed\n");

		// Count the remaining ready processes (if any)
		userprocs = ready_process_count();
	}

	//printf("Kernel Process Terminated\n");
	printf("\nKernel Process Exiting...\n");
}

// The user processes

void proc_a()
{
	// print "A"
	printf("A");
	//Exits
	exit();
}

void proc_b()
{
	// print "B"
	printf("B");
	//Yields
	yield();
	// print "B"
	printf("B");
	//Exits
	exit();
}

void proc_c()
{
	// print "C" 
	printf("C");
	//Yields
	yield();
	// print "C"
	printf("C");
	//Yields
	yield();
	// print "C"
	printf("C");
	//Yields
	yield();
	// print "C"
	printf("C");
	//Exits
	exit();
}

void proc_d()
{
	// print "D"
	printf("D");
	//Yields
	yield();
	// print "D"
	printf("D");
	//Yields
	yield();
	// print "D"
	printf("D");
	//Exits
	exit();
}
void proc_e()
{
	// print "E"
	printf("E");
	//Yields
	yield();
	// print "E"
	printf("E");
	//Exits
	exit();
}