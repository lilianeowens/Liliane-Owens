/*Mugisha Liliane Abizera
 CIS 1111
 Arrays Assignment
 7/27/2021*/

#include<iostream>
#include<string>

using namespace std;

void displayCodes(int c[], int num)
{
	for (int i = 0; i < num; i++)
		cout << c[i] << endl;

}
int AddCodes(int a[], int nu)
{
	int codes;
	
    cout <<"enter the product code:"<< endl;
	cin >> a[nu];
	nu++;
	return nu;
}
int removeCodes(int r[], int count)
{
	int position{};
	int code;
	cout << "What codes do you want remove: ";
	cin >> code; 
	for (int i = 0; i < count; i++)
		
	if (r[i] == code)
	{
	position = i;
	}
	for (int i = position; i < count; i++)
		r[i] = r[i + 1];
	count--;
	return count;
}

int main()
{
	int codes[1000];
	int count = 0, choice;
	const int add_Codes = 1, 
		      remove_Codes = 2, 
		      display_Codes = 3, 
		      End_order = 4;

	do {
		//display menu
		cout << "Enter 1 to add codes"<<endl;
		cout << "Press 2 to remove codes"<<endl;
		cout << "Press 3 to display product codes"<<endl;
		cout << "Press 4  to end the codes"<<endl<< endl;
		cout << "Enter your choice: ";
		cin >> choice;
		
			// Validation
		
		while (choice< add_Codes || choice > End_order)
		{
			cout << "Error! enter the valid menu choice:";
			cin >> choice;
		}
		//get choice
		if (choice == 1) {
			//add codes
			count = AddCodes(codes, count);}
			
		else if (choice == 2) {
			//remove codes
			count= removeCodes(codes,count);}

		else if (choice == 3) {
			displayCodes(codes, count);}

		else if (choice == 4) {
		}
		
	} while (choice != End_order);
	
	return 0;

}