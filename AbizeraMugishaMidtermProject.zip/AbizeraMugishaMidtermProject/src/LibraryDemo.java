import java.util.Scanner;

public class LibraryDemo {
	// main method to run the MediaItem class
	public static void main(String[] args) {
		int menu = 0;
		String title;
		String format;
		String name;
		String date;
		boolean found;

		String[] list = new String[SIZE];

		do {
			menu = displayMenu();
			switch(menu) {

			case 1: // Add new item
				System.out.print("What is the title?: ");
				title = IN.nextLine();
				System.out.print("What is the format?: ");
				format = IN.nextLine();
				System.out.printf("%n");
				addNewItem(title, format);
				break;

			case 2: // Mark an item as on Loan
				System.out.print("Which item (enter the title)? ");
				title = IN.nextLine();
				found = false;

				for(int i = 0; i < numberOfItems; i++) {
					if (items[i].getTitle().equalsIgnoreCase(title)) {
						found = true;
					}
				}
				if (found) {
					System.out.print("Who are you loaning it to? ");
					name = IN.nextLine();
					System.out.print("When did you loan it to them? ");
					date = IN.nextLine();
					markItemOnLoan(title, name, date);
					System.out.printf("%n");

				}
				else {
					System.out.printf("I am sorry, I could not find %s in the library.%n%n", title);
				}
				break;

			case 3: //List all items
				list = listAllItems();
				for(int i = 0; i < numberOfItems; i++) {
					System.out.println(list[i]);
				}
				System.out.printf("%n");
				break;

			case 4: //Mark an item as returned
				System.out.print("Which item(enter the title)? ");
				title = IN.nextLine();
				found = false;

				for(int i = 0; i < numberOfItems; i++) {
					if (items[i].getTitle().equalsIgnoreCase(title)) {
						found = true;
					}
				}
				if (found) {
					markItemReturned(title);
					System.out.printf("%n");
				}else {
					System.out.printf("I am sorry, I could not find %s in the library.%n%n", title);
				}
				break;

			case 5: //Quit
				System.out.print("Goodbye!");
				break;

			}
		}while(menu!= 5);

	}
	private static final Scanner IN = new Scanner(System.in);
	private static final int SIZE = 100; 
	private static MediaItem[] items = new MediaItem[SIZE];
	private static int numberOfItems = 0;

	public static int displayMenu() {
		int menu = 0;
		String captureInvalid;
		System.out.printf(
				"1. Add new item%n" + 
				"2. Mark an item as on loan%n" + 
				"3. List all items%n" + 
				"4. Mark an item as returned%n" + 
				"5. Quit%n");
		System.out.print("What would you like to do? :");
		while(menu < 1 || menu > 5) {
			if(IN.hasNextInt()) {
				menu = IN.nextInt();
				IN.nextLine();
				if (menu < 1 || menu > 5) {
					System.out.printf("I am sorry, %d wasn't one of the options.%n", menu);
					System.out.print("What would you like to do? :");
				}
			}
			else {
				captureInvalid = IN.nextLine();
				System.out.printf("I am sorry, %s was an invalid input.%n" , captureInvalid);
				System.out.print("What would you like to do? :");
			}
		}
		return menu;
	}
	private static void addNewItem (String title, String format) {
		if(numberOfItems == SIZE) {
			System.out.printf("I am sorry, you have reached the limits of the library.%n%n");
		}
		else items[numberOfItems] = new MediaItem(title,format);

		numberOfItems++;
	}

	private static void markItemOnLoan (String title, String name, String date) {
		for(int i= 0; i< numberOfItems; i++) {
			if(items[i].getTitle().equalsIgnoreCase(title)) {
				items[i].markOnLoan(name,date);
			}
		}
	}
	private static String[] listAllItems() {
		String[] list = new String[SIZE];

		for(int i = 0; i < numberOfItems; i++) {

			if(items[i].isOnLoan()) {
				list[i]= String.format("%s (%s) loaned to %s on %s.",
						items[i].getTitle(), items[i].getFormat(),
						items[i].getLoanedTo(), items[i].getDateLoaned());

			}
			else {
				list[i] = String.format("%s (%s)",
						items[i].getTitle(), items[i].getFormat());
			}
		}
		return list;
	}

	private static void markItemReturned(String title) {
		for(int i = 0; i < numberOfItems; i++) {
			if(items[i].getTitle().equalsIgnoreCase(title)) {
				items[i].markReturned();
			}
		}
	}
}
