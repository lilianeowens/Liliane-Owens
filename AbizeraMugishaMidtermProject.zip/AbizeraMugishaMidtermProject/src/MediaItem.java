
public class MediaItem {

	private String title,
				   format,
				   loanedTo,
				   dateLoaned;
	private boolean onLoan;

	public MediaItem() {
		       title = null;
		       format = null;
		       loanedTo = null;
		       dateLoaned = null;
		       onLoan = false;
	}
	public MediaItem(String title, String format) {

		this.title = title;
		this.format = format;
		this.onLoan = false;

		loanedTo = null;
		dateLoaned = null;
		
	}

	//return the title

	public String getTitle() {
	return title;
	}
	//Set the title 

	public void setTitle(String title) {
		this.title = title;
	}
	//return the format

	public String getFormat() {
		return format;
	}
	//Set the format

	public void setFormat(String format) {
		this.format = format;
	}
	//return the loanedTo

	public String getLoanedTo() {
		return loanedTo;
	}
	//Set loanedTo 

	public void setLoanedTo(String loanedTo) {
		this.loanedTo = loanedTo;
	}
	//return the dateLoaned

	public String getDateLoaned() {
		return dateLoaned;
	}
	// set dateLoaned 

	public void setDateLoaned(String dateLoaned) {
		this.dateLoaned = dateLoaned;
	}
	//return the onLoan

	public boolean isOnLoan() {
		return onLoan;
	}
	// Set onLoan

	public void setOnLoan(boolean onLoan) {
		this.onLoan = onLoan;
	}
	// mark which item is on loan
	public void markOnLoan(String name, String date) {

		if (onLoan == true) {
			System.out.printf("%s is already on loan to %s.%n ", title, loanedTo);		
		}

		else {
			onLoan = true;
			loanedTo = name;
			dateLoaned = date;
		}
	}
	
	//mark the item they returned 
	public void markReturned() {
		if(onLoan == true) {
			onLoan = false;
		}
		else {
			System.out.printf("%s is not currently on loan.%n", title);
		}
	}

}

