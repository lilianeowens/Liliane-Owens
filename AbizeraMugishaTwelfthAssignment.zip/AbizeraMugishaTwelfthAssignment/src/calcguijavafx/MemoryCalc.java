package calcguijavafx;

public class MemoryCalc {

		private double currentValue;
		private double operand;
		
		private boolean clearStatus = false;
		
		public double getCurrentValue() {
			return currentValue;
		}

		public void setCurrentValue(double currentValue) {
			this.currentValue = currentValue;
		}
		
		public double getOperand() {
			return operand;
		}
		
		public void setOperand(double operand) {
			this.operand = operand;
		}
		
		public boolean getClearStatus() {
			return clearStatus;
		}
		
		public void setClearStatus(boolean clearStatus) {
			this.clearStatus = clearStatus;
		}

		public void add() {
			clearStatus = false;
			currentValue += operand;
		}
		
		public void subtract() {
			clearStatus = false;
			currentValue -= operand;
		}
		
		public void multiply() {
			clearStatus = false;
			currentValue *= operand;
		}
		
		public void divide() {
			clearStatus = false;
			
			if (operand == 0) {
				currentValue /= Double.NaN;
			} else {
				currentValue /= operand;
			}
		}

		public void clear() {
			clearStatus = true;
			currentValue = 0;
			operand = 0;
		}

		@Override
		public String toString() {
			StringBuilder builder = new StringBuilder();
			builder.append("MemoryCalc [currentValue=");
			builder.append(currentValue);
			builder.append(", clearStatus=");
			builder.append(clearStatus);
			builder.append(", getCurrentValue()=");
			builder.append(getCurrentValue());
			builder.append(", getClearStatus()=");
			builder.append(getClearStatus());
			builder.append(", getClass()=");
			builder.append(getClass());
			builder.append(", hashCode()=");
			builder.append(hashCode());
			builder.append(", toString()=");
			builder.append(super.toString());
			builder.append("]");
			return builder.toString();
		}
	}
	