/*Mugisha Liliane Abizera 
CIS 1111
7/7/2021
Files Assignment */


#include<iostream>
#include<fstream>
#include<string>
#include<iomanip>
using namespace std;

int main()
{
//opening file for writing
	ofstream outFile;
	outFile.open("agent.txt");
	if (outFile.fail())
	{
		cout << "Error opening File. \n";
	}
	else
	{
// process the file.
	}
	string filename;
		
	if (outFile.is_open()) {

	int price;
	string name, Yes_No;
	double total = 0.0, average, nuagent;

	do
	{
	cout << "Enter name of agent : ";
	cin >> name;
	outFile << name << " ";
	cout << "enter the sale price of house 1:" << " ";
	cin >> price;
	outFile << price << " ";
	cout << "enter the sale price of house 2:" << " ";
	cin >> price;
	outFile << price << " ";
	cout << "enter the sale price of house 3:" << " ";
	cin >> price;
	outFile << price << " ";
	cout << "enter the sale price of house 4:" << " ";
	cin >> price;
	outFile << price << " ";
	cout << "Want to enter more agent name data?(Y/N) ";
	cin >> Yes_No;
	cout << "\n";
	} 		while (Yes_No == "Y" || Yes_No == "y");

		
//close the file
outFile.close();

//-------------------------------------
//opening file for reading
	ifstream inFile;
	inFile.open(filename.c_str());
	inFile.open("agent.txt");
	if (inFile.fail())
	{
	cout << "Filename opening error !!! \n";
		}
	else 
		{
				//cout << "Process the file .";
	}

	if (inFile.is_open()) {
				
	int agentTotal = 0;//add accumulators
	double agencytotal = 0.0;
				
	while (inFile >> name)
	{
//for loop for reading price for agent
	agentTotal = 0;
	for (int h = 0; h < 4; h++) {
	inFile >> price;
	agentTotal += price;
	total++;
	}
			
//calculate agent average
	cout << setprecision(2) << fixed;
	cout << "Agent " << name << " "<< "total sales were "<<" "<<"$" << agentTotal << " average price was $ " << setw(2) << (double)(agentTotal / 4.0) << endl << endl;
    agencytotal += agentTotal;
								
	}
	cout << "The total sales for the agency was $" << agencytotal << endl;
// calculate agency average
	double averageagency = agencytotal / total;
					
	cout << setprecision(2) << fixed;
	cout << "For the average sale for the agency was $" << setw(2) <<averageagency<< endl;
				
	int highest = 0.00, highestsales;
	if (agentTotal > highest)
	{
	highest = agentTotal;
	highestsales = price;
	cout << "The agent with the highest sales = " << name <<" "<< "with sales of $" << agentTotal <<endl << endl;
							
	}

	}

cout << "Done \n";
//close the file
inFile.close();
		}
return 0;
}


