import java.util.Objects;
import java.util.Scanner;

/**
 * 
 */

/**
 * 
 *
 */
public class MemoryCalculator {
	
	private double currentValue = 0.0;

	public static int displayMenu() {
		int menu = 0;
		double currentValue = 0.0;

		Scanner input = new Scanner(System.in);	

		System.out.print(
				" The current value is  " + "\n" + currentValue + 
				" Menu\n" + 
						" 1. Add\n" + 
						" 2. Substract\n" +
						" 3. Multiply\n" + 
						" 4. Didide\n " + 
						" 5. clear\n " +
						" 6. Quit\n\n");

		System.out.print("What would you like to do? ");

		menu =input.nextInt();
		/*
		 * String message = " what is the second number ?"; double operand2; int choice;
		 * do { choice = displayMenu(); //while (choice != 6) {
		 * 
		 * switch (choice) {
		 * 
		 * case 1:// Add //System.out.print("How many values are in the arrays? ");
		 * //size = inKeyboard.nextInt();
		 * 
		 * 
		 * operand2 = getOperand(message);
		 * 
		 * add(operand2);
		 * 
		 * System.out.println("The current value is  " + obj1 );
		 * 
		 * break;
		 * 
		 * case 2: // Subtract
		 * 
		 * operand2 = getOperand(message);
		 * 
		 * subtract(operand2); System.out.println("The current value is  " + obj1);
		 * 
		 * break;
		 * 
		 * case 3:// Multiply operand2 = getOperand(message);
		 * 
		 * multiply(operand2); System.out.println("The current value is  " + obj1);
		 * 
		 * break;
		 * 
		 * case 4: // Divide //operand2 = getOperand(message);
		 * 
		 * divide(operand2); System.out.println("The current value is  " + obj1);
		 * 
		 * break;
		 * 
		 * case 5: // Clear clear(0.0);
		 * 
		 * System.out.println("The current value is  " + obj1); break;
		 * 
		 * 
		 * case 6:// Quit System.out.println("Goodbye!"); break;
		 * 
		 * default: System.out.println("I am sorry, " + choice +
		 * " was not one of the options.\n"); }
		 * 
		 * }while(choice != 6);
		 * 
		 * inKeyboard.close(); } }
		 */
		return menu;
	}
	 
	public static double getOperand(String prompt) {
		Scanner in = new Scanner(System.in);
		System.out.print(prompt);

		double result = in.nextDouble();

		return result;
	}
	//public MemoryCalculator(double newCurrentValue) {
	//	currentValue = newCurrentValue;
	//}
	
	public double getCurrentValue() {
		return currentValue;
	}
public void add(double operand2) {
	currentValue += operand2;
}
public void subtract(double operand2) {
	currentValue -= operand2;
}
public void multiply(double operand2) {
	currentValue *= operand2;
}
public void divide(double operand2) {
	if (operand2 == 0) {
	currentValue /= Double.NaN;}
	else
	currentValue /= operand2;
}
	public void clear(double currentValue) {
		this.currentValue = currentValue;
	}

	@Override
	public int hashCode() {
		return Objects.hash(currentValue);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MemoryCalculator other = (MemoryCalculator) obj;
		return Double.doubleToLongBits(currentValue) == Double.doubleToLongBits(other.currentValue);
	}

	@Override
	public String toString() {
		return "MemoryCalculator [currentValue=" + currentValue + "]";
	}

}
