import java.util.Scanner;

public class TestMemoryCalculator {

	
	
	  public static int displayMenu() { 
		  
		  int menu = 0; 
		  double currentValue = 0.0;
	  
		  
	  Scanner input = new Scanner(System.in);
	  
	  
	  System.out.print(
			      "Menu\n" + 
			  		 "1. Add\n"+ 
					  " 2. Substract\n" +
	                 " 3. Multiply\n" + 
					 " 4. Didide\n " + 
	                 " 5. clear\n " + 
					 " 6. Quit\n\n");
	  
	  System.out.print("What would you like to do? ");
	  
	  menu =input.nextInt();
	//  } while(menu < 1 || menu > 6); 
	  
	  return menu; 
	  
	  }
	  public static double getOperand(String prompt) {
		  Scanner in = new Scanner(System.in); 
		  System.out.print(prompt);
		 
	  
	  double operand = in.nextDouble();
	  
	  return operand; 
	  }
	 
	
	public static void main(String[] args) {
		Scanner inKeyboard = new Scanner(System.in);	
		String message = " what is the second number ?";
		 double operand2;
		 
		MemoryCalculator obj1 = new MemoryCalculator();
		MemoryCalculator currentValue = new MemoryCalculator();
		System.out.println(" The current value is  " + obj1.getCurrentValue() );
		int choice;
		do {
			 choice = displayMenu();
			//while (choice != 6) {
			
			switch (choice) { 
			
			case 1:// Add
				//System.out.print("How many values are in the arrays? ");
				//size = inKeyboard.nextInt();

				
				operand2 = getOperand(message);
				
				obj1.add(operand2);
			   
				System.out.println("The current value is  " + obj1 + currentValue );
 
				break;
			
			case 2: // Subtract 
				
			operand2 = getOperand(message);

				obj1.subtract(operand2);
				System.out.println("The current value is  " + obj1);

				break;
			
			case 3:// Multiply 
				operand2 = getOperand(message);

				obj1.multiply(operand2);
				System.out.println("The current value is  " + obj1);

				break;
			
			case 4: // Divide 
				operand2 = getOperand(message);

				obj1.divide(operand2);
				System.out.println("The current value is  " + obj1);

				break;
			
			case 5: // Clear
				obj1.clear(0.0);

		    	System.out.println("The current value is  " + obj1);
				break;
			
			
			case 6:// Quit 
				System.out.println("Goodbye!"); 
				break;
			
			default:
				System.out.println("I am sorry, " + choice + " was not one of the options.\n");
			}
		
			}while(choice != 6);

		inKeyboard.close();
		}
	}


	


			

	


