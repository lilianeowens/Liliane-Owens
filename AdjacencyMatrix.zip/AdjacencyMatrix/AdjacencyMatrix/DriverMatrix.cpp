//File name: main.cpp

/**@author Liliane Owens
CIS 2207 NO1
11/27/22 */
/*This program implement the GraphInterface as given in Listing 20-1.
Using Adjacency Matrix to represent the graph*/

//Include Headers
#include<iostream>
//include Graph.cpp file
#include "Graph.cpp"
using namespace std;

//Program Begins with a main function
int main()
{
	//Declare variables
	int NodeNum, MaxiEdge, Start, End;
	//Prompt the vertices
	cout << "Enter vertices count: ";
	//Get the number of vertices
	cin >> NodeNum;
	//Create object for the Graph class
	Graph<int> graph(NodeNum);
	
	//Assign the node num
		MaxiEdge = NodeNum * (NodeNum - 1);
	//Use for loop to get the edges
	for (int it = 0; it < MaxiEdge; it++)
	{
		//Prompt the edges
		cout << "Enter -1 -1 to exit: ";
		//Get the start and end
		cin >> Start >> End;
		//Check the start and the end
		if ((Start == -1) && (End == -1))
			//break statement
			break;
		//call the add() Method
		graph.add(Start, End);
	}
	//Call the display() Method
	graph.display();
	//To pause the result
	system("pause");
	//Return statement
	return 0;
}
