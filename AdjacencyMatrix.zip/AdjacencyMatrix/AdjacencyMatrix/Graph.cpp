
//File name: Graph.cpp
/**@author Liliane Owens
CIS 2207 NO1
11/27/22 */
/*This program implement the GraphInterface as given in Listing 20-1.
Using Adjacency Matrix to represent the graph*/

//Include Graph.h
#include "Graph.h"
//Include Header files
#include<iostream>
using namespace std;

//Define the constructor for Graph
template<class LabelType>
Graph<LabelType>::Graph(LabelType nVal)
{
	//Assign this to nVal
	this->nVal = nVal;
	//Assign new visitedEdge
	visitedEdge = new bool[nVal];
	//Assign the nVal
	adj = new int* [nVal];
	//Use for loop to new Val
	for (int it = 0; it < nVal; it++)
	{
		//Assign the new nVal
		adj[it] = new int[nVal];
		//Use for loop to new Val
		for (int jth = 0; jth < nVal; jth++)
		{
			//Assign adj as 0
			adj[it][jth] = 0;
		}
	}
}

//Define the Method add() to add the vertices
template<class LabelType>
void Graph<LabelType>::add(LabelType start, LabelType end)
{
	//Check the conditions for start and end
	if (start > nVal || end > nVal || start < 0 || end < 0)
	{
		//Statement to print
		cout << "Invalid edge!"<<"\nVal";
	}
	//else statement
	else
	{
		//Assign a value 1
		adj[start - 1][end - 1] = 1;
}
	}//end add method

//Define the Method display() to display the graph
template<class LabelType>
void Graph<LabelType>::display() {
	//Declare local variables
	int it, jth;
	cout << "\n\n Adjacency Matrix Representation:";
	//Use for loop to print
	for (it = 0; it < nVal; it++) {
		cout << "\n";
		//Use for loop to print
		for (jth = 0; jth < nVal; jth++) {
	cout <<" " << adj[it][jth];
		}
			//Statement to print
		//cout << "\nThis is the Matrix list";
				//To print a new line
		cout << endl;
		
	}
}//end display method

//Define the Method getNumVertices() to get vertices
template<class LabelType>
int Graph<LabelType>::getNumVertices()const
{
	//return the number ofVertices
	return numOfVertices;
}//end getNumVertices

//Define the Method getNumEdges() to get edges
template<class LabelType>
int Graph<LabelType>::getNumEdges()const
	{
		//return the edges
		return numOfEdges;
	}//end getNumEdges

//Define the Method getEdgeWeight() to get edges weight
template<class LabelType>
int Graph<LabelType>::getEdgeWeight(LabelType start, LabelType end)const
{
	//return the numOFVertices
	return numOfVertices;
}

//Define a Method remove() to remove the graph
template<class LabelType>
bool Graph<LabelType>::remove(LabelType start, LabelType end)
{
	//return the result as false
	bool result = false;
	//Check the start and End
	if (start > nVal || end > nVal || start < 0 || end < 0)
	{
		//Statement to print
		cout << "Invalid edge!"<<"\nVal";
	}
	//else statement
	else
	{
		//Assign start as -1
		adj[start - 1][end - 1] = -1;
	}
	//return the result
	return result;
}//end Graph.cpp
	