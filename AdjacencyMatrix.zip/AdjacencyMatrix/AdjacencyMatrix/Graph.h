#pragma once
//File name:Graph.h
/**@author Liliane Owens
CIS 2207 NO1
11/27/22 */
/*This program implement the GraphInterface as given in Listing 20-1.
Using Adjacency Matrix to represent the graph*/

//Define Headers
#ifndef _GRAPH
#define _GRAPH
//Include GraphInterface.h
#include"GraphInterface.h"
//Declare the class Graph
template <class LabelType>
class Graph :public GraphInterface<LabelType>
{
	//Access Specifier
private:
	//Declare a variable
	LabelType nVal;
	//Declare a variable
	LabelType** adj;
	//Declare a variable
	bool* visitedEdge;
	//Declare a variable
	int edgeWeight;
	//Declare a variable
	int numOfEdges;
	//Declare a variable
	int numOfVertices;
	
	//Access specifier
public:
	//Declare a constructor
	Graph(LabelType n);
	//Declare a method getNumVertices()
	int getNumVertices()const;
	//Declare a method getNumEdges()
	int getNumEdges() const;
	//Declare a Method getEdgeWeight()
	int getEdgeWeight(LabelType start, LabelType end)const;
	//Declare a Method add()
	void add(LabelType start, LabelType end);
	//Declare a Method remove()
	bool remove(LabelType start, LabelType end);
	//Declare a Method display()
	void display();
};//end Graph.h
#endif