#pragma once
//@FileName:GraphInterface.h
/**@author Liliane Owens
CIS 2207 NO1
11/27/22 */
/*This program implement the GraphInterface as given in Listing 20-1.
Using Adjacency Matrix to represent the graph*/
//Headers
#ifndef _GRAPH_INTERFACE
#define _GRAPH_INTERFACE
//Declare the template class GraphInterface
template<class LabelType>
class GraphInterface
{
	//Access specifier
public:
	//Declare the method getNumVertices()
	virtual int getNumVertices() const = 0;
	//Declare the method getNumEdges()
	virtual int getNumEdges()const = 0;
	//Declarethe method add() to add the vertices
	virtual void add(LabelType start, LabelType end) = 0;
	/*Declare the method remove() to remove the vertices*/
	virtual bool remove(LabelType start, LabelType end) = 0;
	/*Declare the method getEdgeWeight() to get edge weight*/
	virtual int getEdgeWeight(LabelType start, LabelType end) const = 0;
	//Declare the method display()
	virtual void display() = 0;
};//end GraphInterface.h
#endif