package binarySearchTree;

import java.util.Comparator;
import java.util.Scanner;

public class driverBST {

	public static void main(String[] args) {

		BSTWithHeight<String> tree = new BSTWithHeight<>();
		System.out.print("The height of an empty tree is " + tree.height());

		tree.insert("Green");
		System.out.print("\nThe height of the tree with one node is " + tree.height());

		tree.insert("Red");
		System.out.print("\nThe height of the tree with two nodes is " + tree.height());

		Scanner input = new Scanner(System.in);
		System.out.print("\nEnter six strings: ");
		for (int i = 0; i < 6; i++) {
			String s = input.next();
			tree.insert(s.trim());
		}
		System.out.print("The height of tree is " + tree.height());

		BSTWithHeight<String> tree1 = new BSTWithHeight<>(new String[] { "Tom", "George", "Jean", "Jane", "Kevin",
				"Peter", "Susan", "Jen", "Kim", "Michael", "Michelle" });
		tree1.setComparator( new StrComparator() );

		System.out.print("\nThe height of tree1 is " + tree1.height());

		BSTWithHeight<Integer> tree2 = new BSTWithHeight<>(new Integer[] { 50, 45, 35, 48, 59, 51, 58 });
		tree2.setComparator( new IntComparator() );

		System.out.print("\nThe height of tree2 is " + tree2.height());
	}
}


class StrComparator implements Comparator<String> {

	@Override
	public int compare(String o1, String o2) {

		return o1.compareTo(o2);
	}

}


class IntComparator implements Comparator<Integer> {

	@Override
	public int compare(Integer o1, Integer o2) {

		return o1.compareTo(o2);
	}

}



class BSTWithHeight<E> extends BST<E> {
	/** Create a default BST with a natural order comparator */
	public BSTWithHeight() {
		super();
	}

	/** Create a BST with a specified comparator */
	public BSTWithHeight(java.util.Comparator<E> c) {
		super(c);
	}

	/** Create a binary tree from an array of objects */
	public BSTWithHeight(E[] objects) {
		super(objects);
	}
	public void setComparator(java.util.Comparator<E> c) {
		this.c = c;

	}


	/**
	 * Returns the height of this binary tree.
	 */

	/** BreadthFirst traversal from the root */
	public void breadthFirstTraversal() {
		int h = height(root);
		for (int i = 1; i <= h; i++) {
			breadthFirstTraversal(root, i);
		}
	}

	@SuppressWarnings("rawtypes")
	public void breadthFirstTraversal(TreeNode root, int level) {

		if (root == null) {
			return;
		}
		if (level == 1) {
			System.out.print(root.element + " ");
		} else if (level > 1) {
			breadthFirstTraversal(root.left, level - 1);
			breadthFirstTraversal(root.right, level - 1);
		}
	}

	public int height() {
		return height1(root);
	}

	@SuppressWarnings("unused")
	private int height1(TreeNode<E> root) {
		if (root == null) {
			return 0;
		} else {
			int lefth = height(root.left);
			int righth = height(root.right);

			if (lefth > righth) {
				return (lefth + 1);
			} else {
				return (righth + 1);
			}
		}

	}

}




